# 华南师范大学滨海校园预约服务平台 API 文档

## 基础信息

- 基础URL: `http://localhost:8080/api`
- 所有请求返回格式为JSON
- 认证采用JWT Token，在请求头中添加 `Authorization: Bearer {token}`

## 通用返回格式

```json
{
  "code": 200,     // 状态码：200成功，500失败
  "message": "操作成功", // 提示信息
  "data": {}      // 返回数据，根据接口不同而不同
}
```

## 用户模块

### 登录

- URL: `/user/login`
- 方法: POST
- 描述: 用户登录接口
- 请求参数:

```json
{
  "username": "string", // 用户名/手机号
  "password": "string"  // 密码
}
```

- 响应:

```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "string", // JWT Token
    "user": {
      "id": 1,
      "username": "string",
      "realName": "string",
      "phone": "string",
      "email": "string",
      "avatar": "string",
      "status": 1
    }
  }
}
```

### 注册

- URL: `/user/register`
- 方法: POST
- 描述: 用户注册接口
- 请求参数:

```json
{
  "username": "string", // 用户名/学号
  "password": "string", // 密码
  "realName": "string", // 真实姓名
  "phone": "string",    // 手机号
  "email": "string"     // 邮箱
}
```

- 响应:

```json
{
  "code": 200,
  "message": "注册成功",
  "data": null
}
```

### 更新用户信息

- URL: `/user/update`
- 方法: PUT
- 描述: 更新用户信息
- 请求参数:

```json
{
  "realName": "string", // 真实姓名
  "phone": "string",    // 手机号
  "email": "string",    // 邮箱
  "avatar": "string"    // 头像URL
}
```

- 响应:

```json
{
  "code": 200,
  "message": "更新成功",
  "data": null
}
```

### 更新密码

- URL: `/user/password`
- 方法: PUT
- 描述: 更新用户密码
- 请求参数:

```json
{
  "oldPassword": "string", // 旧密码
  "newPassword": "string"  // 新密码
}
```

- 响应:

```json
{
  "code": 200,
  "message": "密码更新成功",
  "data": null
}
```

### 更新FCM令牌

- URL: `/user/fcm-token`
- 方法: PUT
- 描述: 更新用户FCM令牌
- 请求参数:

```json
{
  "fcmToken": "string" // FCM令牌
}
```

- 响应:

```json
{
  "code": 200,
  "message": "更新成功",
  "data": null
}
```

### 获取当前用户信息

- URL: `/user/me`
- 方法: GET
- 描述: 获取当前登录用户的信息
- 请求参数: 无（通过JWT Token识别用户）

- 响应:

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "username": "string",
    "realName": "string",
    "phone": "string",
    "email": "string",
    "avatar": "string",
    "status": 1,
    "fcmToken": "string"
  }
}
```

## 空间模块

### 获取空间列表

- URL: `/space/list`
- 方法: GET
- 描述: 获取空间列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）
  - `spaceType`: 空间类型（可选）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "name": "会议室A",
        "description": "string",
        "location": "string",
        "capacity": 20,
        "imageUrl": "string",
        "spaceType": 1,
        "status": 1
      }
    ],
    "total": 10,
    "size": 10,
    "current": 1
  }
}
```

### 获取空间可用时间段

- URL: `/space/time-slots`
- 方法: GET
- 描述: 获取指定日期的空间可用时间段
- 请求参数:
  - `spaceId`: 空间ID
  - `date`: 日期（格式：yyyy-MM-dd）

- 响应:

```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {
      "startTime": "08:00",
      "endTime": "09:00",
      "available": true
    },
    {
      "startTime": "09:00",
      "endTime": "10:00",
      "available": false
    },
    {
      "startTime": "10:00",
      "endTime": "11:00",
      "available": true
    }
  ]
}
```

### 创建预约

- URL: `/space/booking`
- 方法: POST
- 描述: 创建空间预约
- 请求参数:

```json
{
  "spaceId": 1,            // 空间ID
  "date": "2025-06-11",    // 预约日期
  "startTime": "09:00",    // 开始时间（格式：HH:mm 或 HH:mm:ss）
  "endTime": "10:00",      // 结束时间（格式：HH:mm 或 HH:mm:ss）
  "peopleCount": 5,        // 人数
  "purpose": "string"      // 用途
}
```

- 响应:

```json
{
  "code": 200,
  "message": "预约申请已提交",
  "data": {
    "id": 1 // 预约ID
  }
}
```

### 取消预约

- URL: `/space/booking/{id}/cancel`
- 方法: PUT
- 描述: 取消预约
- 请求参数:
  - `id`: 预约ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "预约已取消",
  "data": null
}
```

### 获取用户预约列表

- URL: `/space/booking/user`
- 方法: GET
- 描述: 获取用户预约列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "spaceId": 1,
        "spaceName": "会议室A", // 关联查询得到
        "startTime": "2023-06-10 14:00",
        "endTime": "2023-06-10 16:00",
        "peopleCount": 5,
        "purpose": "string",
        "status": 1,
        "createTime": "2023-06-09 10:00"
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1
  }
}
```

## 活动模块

### 获取活动列表

- URL: `/activity/list`
- 方法: GET
- 描述: 获取活动列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）
  - `type`: 活动类型（可选）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "title": "活动标题",
        "description": "string",
        "imageUrl": "string",
        "startTime": "2023-06-15 14:00",
        "endTime": "2023-06-15 16:00",
        "location": "string",
        "capacity": 50,
        "registeredCount": 30,
        "type": 1,
        "status": 0,
        "averageRating": 4.5
      }
    ],
    "total": 10,
    "size": 10,
    "current": 1
  }
}
```

### 获取活动详情

- URL: `/activity/{id}`
- 方法: GET
- 描述: 获取活动详情
- 请求参数:
  - `id`: 活动ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "id": 1,
    "title": "活动标题",
    "description": "string",
    "imageUrl": "string",
    "startTime": "2023-06-15 14:00",
    "endTime": "2023-06-15 16:00",
    "location": "string",
    "capacity": 50,
    "registeredCount": 30,
    "type": 1,
    "status": 0,
    "averageRating": 4.5,
    "isRegistered": false, // 当前用户是否已报名
    "isCheckedIn": false // 当前用户是否已签到
  }
}
```

### 活动报名

- URL: `/activity/register`
- 方法: POST
- 描述: 报名活动
- 请求参数:

```json
{
  "activityId": 1  // 活动ID
}
```

- 响应:

```json
{
  "code": 200,
  "message": "报名成功",
  "data": {
    "id": 1 // 报名ID
  }
}
```

### 取消活动报名

- URL: `/activity/registration/{id}/cancel`
- 方法: PUT
- 描述: 取消活动报名
- 请求参数:
  - `id`: 报名ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "取消成功",
  "data": null
}
```

### 活动签到

- URL: `/activity/registration/{id}/check-in`
- 方法: PUT
- 描述: 活动签到
- 请求参数:
  - `id`: 报名ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "签到成功",
  "data": null
}
```

### 活动评价

- URL: `/activity/rating`
- 方法: POST
- 描述: 评价活动
- 请求参数:

```json
{
  "activityId": 1,    // 活动ID
  "rating": 4.5,      // 评分（1-5）
  "comment": "string" // 评价内容
}
```

- 响应:

```json
{
  "code": 200,
  "message": "评价成功",
  "data": null
}
```

### 获取活动评价列表

- URL: `/activity/{id}/ratings`
- 方法: GET
- 描述: 获取活动评价列表
- 请求参数:
  - `id`: 活动ID（路径参数）
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "activityId": 1,
        "userId": 1,
        "username": "string", // 关联查询得到
        "avatar": "string",   // 关联查询得到
        "rating": 4.5,
        "comment": "string",
        "createTime": "2023-06-16 10:00"
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1
  }
}
```

### 获取活动报名列表

- URL: `/activity/registrations`
- 方法: GET
- 描述: 获取用户活动报名列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "activityId": 1,
        "userId": 1,
        "registrationTime": "2023-06-10 14:00",
        "status": 1,
        "reminderSent": 0,
        "checkInStatus": 0,
        "isCheckedIn": false,
        "remark": "string",
        "createTime": "2023-06-09 10:00",
        "activity": {
          "id": 1,
          "title": "活动标题",
          "description": "string",
          "imageUrl": "string",
          "startTime": "2023-06-15 14:00",
          "endTime": "2023-06-15 16:00",
          "location": "string",
          "status": 0,
          "type": 1
        }
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1
  }
}
```

## 志愿服务模块

### 获取志愿服务列表

- URL: `/volunteer/list`
- 方法: GET
- 描述: 获取志愿服务列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "title": "志愿服务标题",
        "description": "string",
        "imageUrl": "string",
        "startTime": "2023-06-20 09:00",
        "endTime": "2023-06-20 17:00",
        "location": "string",
        "capacity": 20,
        "registeredCount": 15,
        "hours": 8.0,
        "status": 0
      }
    ],
    "total": 10,
    "size": 10,
    "current": 1
  }
}
```

### 获取志愿服务详情

- URL: `/volunteer/{id}`
- 方法: GET
- 描述: 获取志愿服务详情
- 请求参数:
  - `id`: 志愿服务ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "id": 1,
    "title": "志愿服务标题",
    "description": "string",
    "imageUrl": "string",
    "startTime": "2023-06-20 09:00",
    "endTime": "2023-06-20 17:00",
    "location": "string",
    "capacity": 20,
    "registeredCount": 15,
    "hours": 8.0,
    "status": 0,
    "isRegistered": false, // 当前用户是否已报名
    "isCheckedIn": false // 当前用户是否已签到
  }
}
```

### 志愿服务报名

- URL: `/volunteer/register`
- 方法: POST
- 描述: 报名志愿服务
- 请求参数:

```json
{
  "serviceId": 1  // 志愿服务ID
}
```

- 响应:

```json
{
  "code": 200,
  "message": "报名成功",
  "data": {
    "id": 1 // 报名ID
  }
}
```

### 取消志愿服务报名

- URL: `/volunteer/registration/{id}/cancel`
- 方法: PUT
- 描述: 取消志愿服务报名
- 请求参数:
  - `id`: 报名ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "取消成功",
  "data": null
}
```

### 志愿服务签到

- URL: `/volunteer/registration/{id}/check-in`
- 方法: PUT
- 描述: 志愿服务签到
- 请求参数:
  - `id`: 报名ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "签到成功",
  "data": null
}
```

### 查询用户志愿工时

- URL: `/volunteer/hours`
- 方法: GET
- 描述: 查询用户志愿工时
- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "totalHours": 24.5 // 总工时
  }
}
```

### 获取志愿服务报名列表

- URL: `/volunteer/registrations`
- 方法: GET
- 描述: 获取用户志愿服务报名列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "serviceId": 1,
        "userId": 1,
        "registrationTime": "2023-06-20 10:00",
        "status": 1,
        "actualHours": 8.0,
        "reminderSent": 0,
        "checkInStatus": 0,
        "isCheckedIn": false,
        "remark": "string",
        "createTime": "2023-06-19 10:00",
        "service": {
          "id": 1,
          "title": "志愿服务标题",
          "description": "string",
          "imageUrl": "string",
          "startTime": "2023-06-20 09:00",
          "endTime": "2023-06-20 17:00",
          "location": "string",
          "hours": 8.0,
          "status": 0
        }
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1
  }
}
```

## 通知模块

### 获取用户通知列表

- URL: `/notification/list`
- 方法: GET
- 描述: 获取用户通知列表
- 请求参数:
  - `current`: 当前页数（默认1）
  - `size`: 每页条数（默认10）

- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "records": [
      {
        "id": 1,
        "title": "通知标题",
        "content": "通知内容",
        "type": 1,
        "targetId": 1,
        "readStatus": 0,
        "createTime": "2023-06-10 10:00"
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1
  }
}
```

### 获取未读通知数量

- URL: `/notification/unread/count`
- 方法: GET
- 描述: 获取未读通知数量
- 响应:

```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "count": 3
  }
}
```

### 标记通知为已读

- URL: `/notification/{id}/read`
- 方法: PUT
- 描述: 标记指定通知为已读
- 请求参数:
  - `id`: 通知ID（路径参数）

- 响应:

```json
{
  "code": 200,
  "message": "标记成功",
  "data": null
}
```

### 标记所有通知为已读

- URL: `/notification/read/all`
- 方法: PUT
- 描述: 标记所有通知为已读
- 响应:

```json
{
  "code": 200,
  "message": "标记成功",
  "data": null
}
``` 
