-- 创建数据库
CREATE DATABASE IF NOT EXISTS student_community DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE student_community;

-- 用户表
CREATE TABLE IF NOT EXISTS `user` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    `username` VARCHAR(50) NOT NULL COMMENT '用户名/学号',
    `password` VARCHAR(100) NOT NULL COMMENT '密码',
    `real_name` VARCHAR(50) COMMENT '真实姓名',
    `phone` VARCHAR(20) COMMENT '手机号',
    `email` VARCHAR(100) COMMENT '邮箱',
    `avatar` VARCHAR(255) COMMENT '头像URL',
    `status` INT DEFAULT 1 COMMENT '用户状态 0-禁用 1-正常',
    `fcm_token` VARCHAR(255) COMMENT 'Firebase消息推送令牌',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_username` (`username`),
    UNIQUE KEY `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 空间表
CREATE TABLE IF NOT EXISTS `space` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '空间ID',
    `name` VARCHAR(100) NOT NULL COMMENT '空间名称',
    `description` TEXT COMMENT '空间描述',
    `location` VARCHAR(255) COMMENT '空间位置',
    `capacity` INT COMMENT '容纳人数',
    `image_url` VARCHAR(255) COMMENT '空间图片URL',
    `space_type` INT COMMENT '空间类型',
    `status` INT DEFAULT 1 COMMENT '空间状态 0-不可用 1-可用',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='空间表';

-- 空间预约表
CREATE TABLE IF NOT EXISTS `space_booking` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '预约ID',
    `space_id` BIGINT NOT NULL COMMENT '空间ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `start_time` DATETIME NOT NULL COMMENT '预约开始时间',
    `end_time` DATETIME NOT NULL COMMENT '预约结束时间',
    `people_count` INT COMMENT '预约人数',
    `purpose` VARCHAR(255) COMMENT '预约用途',
    `status` INT DEFAULT 0 COMMENT '预约状态 0-待审核 1-已通过 2-已拒绝 3-已取消',
    `reminder_time` DATETIME COMMENT '提醒时间',
    `reminder_sent` INT DEFAULT 0 COMMENT '提醒发送状态 0-未发送 1-已发送',
    `remark` VARCHAR(255) COMMENT '备注',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_space_id` (`space_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_start_time` (`start_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='空间预约表';

-- 活动表
CREATE TABLE IF NOT EXISTS `activity` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '活动ID',
    `title` VARCHAR(100) NOT NULL COMMENT '活动标题',
    `description` TEXT COMMENT '活动描述',
    `image_url` VARCHAR(255) COMMENT '活动图片URL',
    `start_time` DATETIME NOT NULL COMMENT '活动开始时间',
    `end_time` DATETIME NOT NULL COMMENT '活动结束时间',
    `location` VARCHAR(255) COMMENT '活动地点',
    `capacity` INT COMMENT '活动容量',
    `registered_count` INT DEFAULT 0 COMMENT '已报名人数',
    `type` INT COMMENT '活动类型',
    `status` INT DEFAULT 0 COMMENT '活动状态 0-未开始 1-进行中 2-已结束 3-已取消',
    `average_rating` FLOAT DEFAULT 0 COMMENT '平均评分',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_start_time` (`start_time`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动表';

-- 活动报名表
CREATE TABLE IF NOT EXISTS `activity_registration` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '报名ID',
    `activity_id` BIGINT NOT NULL COMMENT '活动ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `registration_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '报名时间',
    `status` INT DEFAULT 0 COMMENT '报名状态 0-待审核 1-已通过 2-已拒绝 3-已取消',
    `reminder_sent` INT DEFAULT 0 COMMENT '提醒发送状态 0-未发送 1-已发送',
    `check_in_status` INT DEFAULT 0 COMMENT '签到状态 0-未签到 1-已签到',
    `remark` VARCHAR(255) COMMENT '备注',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_activity_user` (`activity_id`, `user_id`, `deleted`),
    KEY `idx_activity_id` (`activity_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动报名表';

-- 活动评价表
CREATE TABLE IF NOT EXISTS `activity_rating` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '评价ID',
    `activity_id` BIGINT NOT NULL COMMENT '活动ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `rating` FLOAT NOT NULL COMMENT '评分（1-5）',
    `comment` TEXT COMMENT '评价内容',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_activity_user` (`activity_id`, `user_id`, `deleted`),
    KEY `idx_activity_id` (`activity_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动评价表';

-- 志愿服务表
CREATE TABLE IF NOT EXISTS `volunteer_service` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '服务ID',
    `title` VARCHAR(100) NOT NULL COMMENT '服务标题',
    `description` TEXT COMMENT '服务描述',
    `image_url` VARCHAR(255) COMMENT '服务图片URL',
    `start_time` DATETIME NOT NULL COMMENT '服务开始时间',
    `end_time` DATETIME NOT NULL COMMENT '服务结束时间',
    `location` VARCHAR(255) COMMENT '服务地点',
    `capacity` INT COMMENT '服务容量',
    `registered_count` INT DEFAULT 0 COMMENT '已报名人数',
    `hours` FLOAT COMMENT '服务工时',
    `status` INT DEFAULT 0 COMMENT '服务状态 0-未开始 1-进行中 2-已结束 3-已取消',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_start_time` (`start_time`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='志愿服务表';

-- 志愿服务报名表
CREATE TABLE IF NOT EXISTS `volunteer_registration` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '报名ID',
    `service_id` BIGINT NOT NULL COMMENT '服务ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `registration_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '报名时间',
    `status` INT DEFAULT 0 COMMENT '报名状态 0-待审核 1-已通过 2-已拒绝 3-已取消',
    `actual_hours` FLOAT DEFAULT 0 COMMENT '实际工时',
    `reminder_sent` INT DEFAULT 0 COMMENT '提醒发送状态 0-未发送 1-已发送',
    `check_in_status` INT DEFAULT 0 COMMENT '签到状态 0-未签到 1-已签到',
    `remark` VARCHAR(255) COMMENT '备注',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_service_user` (`service_id`, `user_id`, `deleted`),
    KEY `idx_service_id` (`service_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='志愿服务报名表';

-- 意见反馈表
CREATE TABLE IF NOT EXISTS `feedback` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '反馈ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `content` TEXT NOT NULL COMMENT '反馈内容',
    `type` INT COMMENT '反馈类型 1-问题反馈 2-功能建议',
    `contact` VARCHAR(100) COMMENT '联系方式',
    `status` INT DEFAULT 0 COMMENT '状态 0-未处理 1-处理中 2-已处理',
    `reply` TEXT COMMENT '回复内容',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='意见反馈表';

-- 社区帖子表
CREATE TABLE IF NOT EXISTS `community_post` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '帖子ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `title` VARCHAR(100) NOT NULL COMMENT '帖子标题',
    `content` TEXT NOT NULL COMMENT '帖子内容',
    `image_url` TEXT COMMENT '帖子图片URL，多个图片用逗号分隔',
    `type` INT COMMENT '帖子类型 1-心得分享 2-问题求助 3-志愿故事',
    `likes` INT DEFAULT 0 COMMENT '点赞数',
    `comments` INT DEFAULT 0 COMMENT '评论数',
    `status` INT DEFAULT 0 COMMENT '状态 0-待审核 1-已发布 2-已拒绝',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社区帖子表';

-- 帖子评论表
CREATE TABLE IF NOT EXISTS `post_comment` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '评论ID',
    `post_id` BIGINT NOT NULL COMMENT '帖子ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `content` TEXT NOT NULL COMMENT '评论内容',
    `likes` INT DEFAULT 0 COMMENT '点赞数',
    `parent_id` BIGINT DEFAULT 0 COMMENT '父评论ID，如果是一级评论则为0',
    `status` INT DEFAULT 0 COMMENT '状态 0-待审核 1-已发布 2-已拒绝',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_post_id` (`post_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='帖子评论表';

-- 通知表
CREATE TABLE IF NOT EXISTS `notification` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '通知ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `title` VARCHAR(100) NOT NULL COMMENT '通知标题',
    `content` TEXT NOT NULL COMMENT '通知内容',
    `type` INT COMMENT '通知类型 1-系统通知 2-预约通知 3-活动通知 4-志愿服务通知',
    `target_id` BIGINT COMMENT '目标ID，根据类型不同对应不同的ID',
    `read_status` INT DEFAULT 0 COMMENT '已读状态 0-未读 1-已读',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` INT DEFAULT 0 COMMENT '逻辑删除 0-未删除 1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_read_status` (`read_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- 插入管理员账号
INSERT INTO `user` (`username`, `password`, `real_name`, `phone`, `email`, `status`) 
VALUES ('admin', 'e10adc3949ba59abbe56e057f20f883e', '管理员', '13800138000', 'admin@example.com', 1);

-- 插入测试空间数据
INSERT INTO `space` (`name`, `description`, `location`, `capacity`, `image_url`, `space_type`, `status`) 
VALUES 
('多功能厅A101', '可用于小型会议、研讨会等活动', '教学楼A栋一楼', 50, 'https://img1.baidu.com/it/u=3980609580,2945482254&fm=253&fmt=auto&app=138&f=JPEG?w=608&h=455', 1, 1),
('图书馆讨论室B201', '安静的学习讨论空间，配备电子白板', '图书馆二楼', 10, 'https://img2.baidu.com/it/u=1447981410,1592204035&fm=253&fmt=auto&app=120&f=JPEG?w=667&h=500', 2, 1),
('学生活动中心大厅', '举办大型活动的场所', '学生活动中心一楼', 200, 'https://jzgc.cug.edu.cn/__local/C/3D/BD/1590B1D2DC4B02DEF429B7982B1_108C170C_64142.jpg?e=.jpg', 3, 1),
('室外篮球场', '标准篮球场，配有照明设施', '体育中心东侧', 30, 'https://img0.baidu.com/it/u=4170415801,306164279&fm=253&fmt=auto&app=120&f=JPEG?w=425&h=239', 4, 1);

-- 插入测试活动数据
INSERT INTO `activity` (`title`, `description`, `image_url`, `start_time`, `end_time`, `location`, `capacity`, `registered_count`, `type`, `status`) 
VALUES 
('新生迎新晚会', '欢迎2023级新生加入我们的大家庭', 'https://img1.baidu.com/it/u=2693120091,1438055754&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500', '2023-09-10 19:00:00', '2023-09-10 21:00:00', '学生活动中心大厅', 200, 0, 1, 0),
('职业规划讲座', '帮助学生规划未来职业发展', 'https://gqt.mtc.edu.cn/__local/0/F1/A6/441B0EC52DA34B0A85931DF3127_A58883FF_481BE.jpg', '2023-09-15 14:00:00', '2023-09-15 16:00:00', '多功能厅A101', 50, 0, 2, 0),
('校园歌手大赛', '展示你的歌唱才华', 'https://img0.baidu.com/it/u=4177136976,2608325243&fm=253&fmt=auto&app=120&f=JPEG?w=750&h=500', '2023-09-20 18:30:00', '2023-09-20 21:30:00', '学生活动中心大厅', 150, 0, 3, 0);

-- 插入测试志愿服务数据
INSERT INTO `volunteer_service` (`title`, `description`, `image_url`, `start_time`, `end_time`, `location`, `capacity`, `registered_count`, `hours`, `status`) 
VALUES 
('校园环保日', '共同参与校园环境清洁，保护我们的美丽校园', 'https://img0.baidu.com/it/u=1350895024,21612565&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=375', '2023-09-22 09:00:00', '2023-09-22 12:00:00', '校园各处', 50, 0, 3.0, 0),
('敬老院志愿服务', '关爱老人，传递温暖', 'https://img0.baidu.com/it/u=1929722178,1101247509&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=501', '2023-09-25 14:00:00', '2023-09-25 17:00:00', '市敬老院', 20, 0, 3.0, 0),
('图书馆整理', '帮助图书馆整理图书，维护阅读环境', 'https://q0.itc.cn/q_70/images03/20241226/aee79a4b05624065902ed20e5fe9b1d3.jpeg', '2023-09-27 08:30:00', '2023-09-27 11:30:00', '图书馆', 15, 0, 3.0, 0);