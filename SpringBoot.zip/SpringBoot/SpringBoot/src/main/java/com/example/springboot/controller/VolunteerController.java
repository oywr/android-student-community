package com.example.springboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.VolunteerRegistration;
import com.example.springboot.entity.VolunteerService;
import com.example.springboot.service.VolunteerRegistrationService;
import com.example.springboot.service.VolunteerServiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 志愿服务控制器
 */
@RestController
@RequestMapping("/api/volunteer")
@RequiredArgsConstructor
public class VolunteerController {
    
    private final VolunteerServiceService volunteerServiceService;
    private final VolunteerRegistrationService volunteerRegistrationService;
    
    /**
     * 获取志愿服务列表
     */
    @GetMapping("/list")
    public Result<Page<VolunteerService>> listVolunteerServices(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size) {
        
        Page<VolunteerService> page = volunteerServiceService.listServices(current, size);
        return Result.success(page);
    }
    
    /**
     * 获取志愿服务详情
     */
    @GetMapping("/{id}")
    public Result<Map<String, Object>> getVolunteerServiceById(
            @PathVariable Long id,
            @RequestAttribute(value = "userId", required = false) Long userId) {
        VolunteerService service = volunteerServiceService.getById(id);
        
        if (service == null) {
            return Result.error("志愿服务不存在");
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("id", service.getId());
        result.put("title", service.getTitle());
        result.put("description", service.getDescription());
        result.put("imageUrl", service.getImageUrl());
        result.put("startTime", service.getStartTime());
        result.put("endTime", service.getEndTime());
        result.put("location", service.getLocation());
        result.put("capacity", service.getCapacity());
        result.put("registeredCount", service.getRegisteredCount());
        result.put("hours", service.getHours());
        result.put("status", service.getStatus());
        
        // 查询用户是否已报名和签到状态
        boolean isRegistered = false;
        boolean isCheckedIn = false;
        if (userId != null) {
            LambdaQueryWrapper<VolunteerRegistration> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(VolunteerRegistration::getServiceId, id);
            queryWrapper.eq(VolunteerRegistration::getUserId, userId);
            queryWrapper.in(VolunteerRegistration::getStatus, 0, 1); // 待审核或已通过
            
            VolunteerRegistration registration = volunteerRegistrationService.getOne(queryWrapper);
            if (registration != null) {
                isRegistered = true;
                isCheckedIn = registration.getCheckInStatus() == 1;
            }
        }
        result.put("isRegistered", isRegistered);
        result.put("isCheckedIn", isCheckedIn);
        
        return Result.success(result);
    }
    
    /**
     * 报名志愿服务
     */
    @PostMapping("/register")
    public Result<Map<String, Object>> registerVolunteerService(
            @RequestBody Map<String, Long> registerMap,
            @RequestAttribute("userId") Long userId) {
        
        Long serviceId = registerMap.get("serviceId");
        if (serviceId == null) {
            return Result.error("服务ID不能为空");
        }
        
        // 创建报名记录
        VolunteerRegistration registration = new VolunteerRegistration();
        registration.setServiceId(serviceId);
        registration.setUserId(userId);
        
        boolean result = volunteerRegistrationService.register(registration);
        
        if (result) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", registration.getId());
            return Result.success("报名成功", data);
        } else {
            return Result.error("报名失败");
        }
    }
    
    /**
     * 获取志愿服务报名列表
     */
    @GetMapping("/registrations")
    public Result<Map<String, Object>> getRegistrations(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestAttribute("userId") Long userId) {
        
        // 获取用户报名记录
        Page<VolunteerRegistration> page = volunteerRegistrationService.getUserRegistrations(current, size, userId);
        
        // 获取志愿服务IDs
        List<Long> serviceIds = page.getRecords().stream()
                .map(VolunteerRegistration::getServiceId)
                .collect(Collectors.toList());
        
        // 查询志愿服务信息
        Map<Long, VolunteerService> serviceMap = new HashMap<>();
        if (!serviceIds.isEmpty()) {
            List<VolunteerService> services = volunteerServiceService.listByIds(serviceIds);
            serviceMap = services.stream()
                    .collect(Collectors.toMap(VolunteerService::getId, service -> service));
        }
        
        // 组装结果
        List<Map<String, Object>> recordsWithService = new ArrayList<>();
        for (VolunteerRegistration registration : page.getRecords()) {
            Map<String, Object> record = new HashMap<>();
            // 添加报名信息
            record.put("id", registration.getId());
            record.put("serviceId", registration.getServiceId());
            record.put("userId", registration.getUserId());
            record.put("registrationTime", registration.getRegistrationTime());
            record.put("status", registration.getStatus());
            record.put("actualHours", registration.getActualHours());
            record.put("reminderSent", registration.getReminderSent());
            record.put("checkInStatus", registration.getCheckInStatus());
            record.put("remark", registration.getRemark());
            record.put("createTime", registration.getCreateTime());
            
            // 添加签到状态的布尔值，方便前端直接使用
            record.put("isCheckedIn", registration.getCheckInStatus() == 1);
            
            // 添加志愿服务信息
            VolunteerService service = serviceMap.get(registration.getServiceId());
            if (service != null) {
                Map<String, Object> serviceInfo = new HashMap<>();
                serviceInfo.put("id", service.getId());
                serviceInfo.put("title", service.getTitle());
                serviceInfo.put("description", service.getDescription());
                serviceInfo.put("imageUrl", service.getImageUrl());
                serviceInfo.put("startTime", service.getStartTime());
                serviceInfo.put("endTime", service.getEndTime());
                serviceInfo.put("location", service.getLocation());
                serviceInfo.put("hours", service.getHours());
                serviceInfo.put("status", service.getStatus());
                record.put("service", serviceInfo);
            }
            
            recordsWithService.add(record);
        }
        
        // 构建分页结果
        Map<String, Object> result = new HashMap<>();
        result.put("records", recordsWithService);
        result.put("total", page.getTotal());
        result.put("size", page.getSize());
        result.put("current", page.getCurrent());
        
        return Result.success(result);
    }
    
    /**
     * 取消志愿服务报名
     */
    @PutMapping("/registration/{id}/cancel")
    public Result<Void> cancelRegistration(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = volunteerRegistrationService.cancelRegistration(id, userId);
        
        return result ? Result.success("取消成功", null) : Result.error("取消失败");
    }
    
    /**
     * 志愿服务签到
     */
    @PutMapping("/registration/{id}/check-in")
    public Result<Void> checkIn(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = volunteerRegistrationService.checkIn(id, userId);
        
        return result ? Result.success("签到成功", null) : Result.error("签到失败");
    }
    
    /**
     * 获取工时统计
     */
    @GetMapping("/hours")
    public Result<Map<String, Object>> getVolunteerHours(@RequestAttribute("userId") Long userId) {
        Float totalHours = volunteerRegistrationService.countUserHours(userId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("totalHours", totalHours);
        
        return Result.success(result);
    }
    
    /**
     * 获取最新志愿服务
     * @param limit 限制数量
     * @return 志愿服务列表
     */
    @GetMapping("/latest")
    public Result<List<VolunteerService>> getLatestServices(
            @RequestParam(defaultValue = "5") Integer limit) {
        
        List<VolunteerService> services = volunteerServiceService.getLatestServices(limit);
        return Result.success(services);
    }
} 