package com.example.springboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.User;
import com.example.springboot.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 用户控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {
    
    private final UserService userService;
    
    /**
     * 登录
     */
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody Map<String, String> loginMap) {
        log.info("开始处理登录请求");
        
        String username = loginMap.get("username");
        String password = loginMap.get("password");
        
        if (username == null || password == null) {
            log.error("登录失败：用户名或密码为空");
            return Result.error("用户名和密码不能为空");
        }
        
        log.info("用户名和密码验证通过，开始调用服务层登录方法");
        // 登录
        String token = userService.login(username, password);
        log.info("服务层登录方法返回token: {}", token);
        
        if (token == null) {
            log.error("登录失败：token为null");
            return Result.error("用户名或密码错误");
        }
        
        // 查询用户信息
        User user = userService.getByUsername(username);
        if(user == null){
            log.error("登录失败：查询不到用户信息");
            return Result.error("暂无该用户");
        }
        
        log.info("登录成功，开始组装返回结果");
        // 构建返回结果
        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        
        // 移除敏感信息
        user.setPassword(null);
        map.put("user", user);
        
        log.info("登录完成，返回token和用户信息");
        return Result.success("登录成功", map);
    }
    
    /**
     * 注册
     */
    @PostMapping("/register")
    public Result<Void> register(@RequestBody User user) {
        // 参数校验
        if (user.getUsername() == null || user.getPassword() == null) {
            return Result.error("用户名和密码不能为空");
        }
        
        // 注册
        boolean result = userService.register(user);
        
        return result ? Result.success("注册成功", null) : Result.error("注册失败");
    }
    
    /**
     * 获取当前用户信息
     * @param userId 用户ID
     * @return 用户信息
     */
    @GetMapping("/me")
    public Result<User> getCurrentUser(@RequestAttribute("userId") Long userId) {
        // 查询用户信息
        User user = userService.getById(userId);
        
        if (user == null) {
            return Result.error("用户不存在");
        }
        
        // 移除敏感信息
        user.setPassword(null);
        
        return Result.success(user);
    }
    
    /**
     * 更新用户信息
     * @param user 用户信息
     * @param userId 用户ID
     * @return 更新结果
     */
    @PutMapping("/update")
    public Result<Void> updateCurrentUser(@RequestBody User user, @RequestAttribute("userId") Long userId) {
        // 设置用户ID
        user.setId(userId);
        
        // 防止修改敏感信息
        user.setUsername(null);
        user.setPassword(null);
        
        // 更新
        boolean result = userService.updateById(user);
        
        return result ? Result.success("更新成功", null) : Result.error("更新失败");
    }
    
    /**
     * 修改密码
     * @param passwordMap 密码信息
     * @param userId 用户ID
     * @return 修改结果
     */
    @PutMapping("/password")
    public Result<Void> updatePassword(@RequestBody Map<String, String> passwordMap,
                                      @RequestAttribute("userId") Long userId) {
        String oldPassword = passwordMap.get("oldPassword");
        String newPassword = passwordMap.get("newPassword");
        
        // 参数校验
        if (oldPassword == null || newPassword == null) {
            return Result.error("原密码和新密码不能为空");
        }
        
        // 修改密码
        boolean result = userService.updatePassword(userId, oldPassword, newPassword);
        
        return result ? Result.success("密码修改成功", null) : Result.error("密码修改失败");
    }
    
    /**
     * 更新FCM令牌
     * @param tokenMap FCM令牌
     * @param userId 用户ID
     * @return 更新结果
     */
    @PutMapping("/fcm-token")
    public Result<Void> updateFcmToken(@RequestBody Map<String, String> tokenMap,
                                      @RequestAttribute("userId") Long userId) {
        String fcmToken = tokenMap.get("fcmToken");
        
        // 参数校验
        if (fcmToken == null) {
            return Result.error("FCM令牌不能为空");
        }
        
        // 更新FCM令牌
        boolean result = userService.updateFcmToken(userId, fcmToken);
        
        return result ? Result.success("更新成功", null) : Result.error("更新失败");
    }
    
    /**
     * 重置密码
     */
    @PostMapping("/reset-password")
    public Result<Void> resetPassword(@RequestBody Map<String, String> params) {
        String username = params.get("username");
        String phone = params.get("phone");
        String newPassword = params.get("newPassword");
        
        if (username == null) {
            return Result.error("用户名不能为空");
        }
        
        if (newPassword == null) {
            return Result.error("新密码不能为空");
        }
        
        // 验证身份并重置密码
        boolean result = userService.resetPassword(username, phone, newPassword);
        
        return result ? 
            Result.success("密码重置成功", null) : 
            Result.error("身份验证失败，请确认用户名和手机号正确");
    }
    
    /**
     * 分页查询用户列表（管理员功能）
     */
    @GetMapping("/page")
    public Result<Page<User>> page(@RequestParam(defaultValue = "1") Integer current,
                              @RequestParam(defaultValue = "10") Integer size,
                              @RequestParam(required = false) String keyword) {
        Page<User> page = new Page<>(current, size);
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        
        // 关键字搜索
        if (keyword != null && !keyword.isEmpty()) {
            queryWrapper.like(User::getUsername, keyword)
                    .or()
                    .like(User::getRealName, keyword)
                    .or()
                    .like(User::getPhone, keyword);
        }
        
        // 不返回已删除的用户
        queryWrapper.eq(User::getDeleted, 0);
        
        // 按创建时间降序排序
        queryWrapper.orderByDesc(User::getCreateTime);
        
        // 查询并清除密码信息
        userService.page(page, queryWrapper);
        page.getRecords().forEach(u -> u.setPassword(null));
        
        return Result.success(page);
    }
} 