package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.CommunityPost;
import com.example.springboot.mapper.CommunityPostMapper;
import com.example.springboot.service.CommunityPostService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 社区帖子服务实现类
 */
@Service
public class CommunityPostServiceImpl extends ServiceImpl<CommunityPostMapper, CommunityPost> implements CommunityPostService {
    
    @Override
    @Transactional
    public boolean createPost(CommunityPost post) {
        // 设置初始状态为待审核
        post.setStatus(0);
        
        // 初始化点赞数和评论数
        post.setLikes(0);
        post.setComments(0);
        
        return save(post);
    }
    
    @Override
    public Page<CommunityPost> listPosts(Integer current, Integer size, Integer type) {
        Page<CommunityPost> page = new Page<>(current, size);
        LambdaQueryWrapper<CommunityPost> queryWrapper = new LambdaQueryWrapper<>();
        
        // 只查询已发布的帖子
        queryWrapper.eq(CommunityPost::getStatus, 1);
        
        // 如果指定了类型，添加类型筛选条件
        if (type != null) {
            queryWrapper.eq(CommunityPost::getType, type);
        }
        
        // 按创建时间降序排序
        queryWrapper.orderByDesc(CommunityPost::getCreateTime);
        
        return page(page, queryWrapper);
    }
} 