package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Space;
import com.example.springboot.entity.SpaceBooking;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 空间服务接口
 */
public interface SpaceService extends IService<Space> {
    
    /**
     * 获取空间列表
     * @param current 当前页
     * @param size 每页大小
     * @param spaceType 空间类型
     * @return 空间分页
     */
    Page<Space> listSpaces(Integer current, Integer size, Integer spaceType);
    
    /**
     * 获取可用时间段
     * @param spaceId 空间ID
     * @param dateTime 日期时间
     * @param bookings 已有预约列表
     * @return 可用时间段列表
     */
    List<Map<String, Object>> getAvailableTimes(Long spaceId, LocalDateTime dateTime, List<SpaceBooking> bookings);
} 