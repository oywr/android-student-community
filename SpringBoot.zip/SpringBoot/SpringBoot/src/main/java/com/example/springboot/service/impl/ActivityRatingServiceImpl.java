package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Activity;
import com.example.springboot.entity.ActivityRating;
import com.example.springboot.entity.ActivityRegistration;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.ActivityRatingMapper;
import com.example.springboot.mapper.ActivityRegistrationMapper;
import com.example.springboot.service.ActivityRatingService;
import com.example.springboot.service.ActivityService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 活动评价服务实现类
 */
@Service
@RequiredArgsConstructor
public class ActivityRatingServiceImpl extends ServiceImpl<ActivityRatingMapper, ActivityRating> implements ActivityRatingService {
    
    private final ActivityRegistrationMapper activityRegistrationMapper;
    private final ActivityService activityService;
    
    @Override
    @Transactional
    public boolean rateActivity(ActivityRating rating) {
        // 检查评分范围
        if (rating.getRating() < 1 || rating.getRating() > 5) {
            throw new ServiceException("评分必须在1-5之间");
        }
        
        // 检查用户是否参加了该活动
        LambdaQueryWrapper<ActivityRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRegistration::getActivityId, rating.getActivityId());
        queryWrapper.eq(ActivityRegistration::getUserId, rating.getUserId());
        queryWrapper.eq(ActivityRegistration::getStatus, 1); // 已通过的报名
        
        ActivityRegistration registration = activityRegistrationMapper.selectOne(queryWrapper);
        if (registration == null) {
            throw new ServiceException("您未参加该活动，无法评价");
        }
        
        // 检查是否已经评价过
        LambdaQueryWrapper<ActivityRating> ratingQueryWrapper = new LambdaQueryWrapper<>();
        ratingQueryWrapper.eq(ActivityRating::getActivityId, rating.getActivityId());
        ratingQueryWrapper.eq(ActivityRating::getUserId, rating.getUserId());
        
        ActivityRating existRating = getOne(ratingQueryWrapper);
        if (existRating != null) {
            throw new ServiceException("您已经评价过该活动");
        }
        
        // 保存评价
        boolean result = save(rating);
        
        // 更新活动平均评分
        if (result) {
            activityService.updateActivityRating(rating.getActivityId());
        }
        
        return result;
    }
    
    @Override
    @Transactional
    public boolean deleteRating(Long id, Long userId) {
        // 查询评价信息
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getId, id);
        queryWrapper.eq(ActivityRating::getUserId, userId);
        
        ActivityRating rating = getOne(queryWrapper);
        if (rating == null) {
            throw new ServiceException("评价不存在");
        }
        
        // 删除评价
        Long activityId = rating.getActivityId();
        boolean result = removeById(id);
        
        // 更新活动平均评分
        if (result) {
            activityService.updateActivityRating(activityId);
        }
        
        return result;
    }
    
    @Override
    public Page<ActivityRating> getActivityRatings(int current, int size, Long activityId) {
        Page<ActivityRating> page = new Page<>(current, size);
        
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getActivityId, activityId);
        queryWrapper.orderByDesc(ActivityRating::getCreateTime);
        
        return baseMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public ActivityRating getUserRating(Long activityId, Long userId) {
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getActivityId, activityId);
        queryWrapper.eq(ActivityRating::getUserId, userId);
        
        return getOne(queryWrapper);
    }
} 