package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Feedback;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 意见反馈Mapper接口
 */
public interface FeedbackMapper extends BaseMapper<Feedback> {
    
    /**
     * 查询用户的所有反馈
     * @param userId 用户ID
     * @return 反馈列表
     */
    @Select("SELECT * FROM feedback WHERE user_id = #{userId} AND deleted = 0 ORDER BY create_time DESC")
    List<Feedback> selectByUserId(Long userId);
} 