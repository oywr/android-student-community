package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 志愿服务实体类
 */
@Data
@TableName("volunteer_service")
public class VolunteerService {
    
    /**
     * 服务ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 服务标题
     */
    private String title;
    
    /**
     * 服务描述
     */
    private String description;
    
    /**
     * 服务图片URL
     */
    private String imageUrl;
    
    /**
     * 服务开始时间
     */
    private LocalDateTime startTime;
    
    /**
     * 服务结束时间
     */
    private LocalDateTime endTime;
    
    /**
     * 服务地点
     */
    private String location;
    
    /**
     * 服务容量
     */
    private Integer capacity;
    
    /**
     * 已报名人数
     */
    private Integer registeredCount;
    
    /**
     * 服务工时
     */
    private Float hours;
    
    /**
     * 服务状态 0-未开始 1-进行中 2-已结束 3-已取消
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除 0-未删除 1-已删除
     */
    @TableLogic
    private Integer deleted;
} 