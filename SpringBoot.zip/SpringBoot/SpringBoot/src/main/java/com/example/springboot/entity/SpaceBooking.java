package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 空间预约实体类
 */
@Data
@TableName("space_booking")
public class SpaceBooking {
    
    /**
     * 预约ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 空间ID
     */
    private Long spaceId;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 预约开始时间
     */
    private LocalDateTime startTime;
    
    /**
     * 预约结束时间
     */
    private LocalDateTime endTime;
    
    /**
     * 预约人数
     */
    private Integer peopleCount;
    
    /**
     * 预约用途
     */
    private String purpose;
    
    /**
     * 预约状态 0-待审核 1-已通过 2-已拒绝 3-已取消
     */
    private Integer status;
    
    /**
     * 提醒时间
     */
    private LocalDateTime reminderTime;
    
    /**
     * 提醒发送状态 0-未发送 1-已发送
     */
    private Integer reminderSent;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除 0-未删除 1-已删除
     */
    @TableLogic
    private Integer deleted;
} 