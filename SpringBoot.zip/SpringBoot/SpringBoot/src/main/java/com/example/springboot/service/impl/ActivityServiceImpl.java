package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Activity;
import com.example.springboot.entity.ActivityRating;
import com.example.springboot.mapper.ActivityMapper;
import com.example.springboot.mapper.ActivityRatingMapper;
import com.example.springboot.service.ActivityService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 活动服务实现类
 */
@Service
@RequiredArgsConstructor
public class ActivityServiceImpl extends ServiceImpl<ActivityMapper, Activity> implements ActivityService {
    
    private final ActivityRatingMapper activityRatingMapper;
    
    @Override
    public Page<Activity> listActivities(Integer current, Integer size, Integer type) {
        Page<Activity> page = new Page<>(current, size);
        LambdaQueryWrapper<Activity> queryWrapper = new LambdaQueryWrapper<>();
        
        // 根据类型筛选
        if (type != null) {
            queryWrapper.eq(Activity::getType, type);
        }
        
        // 只查询未取消的活动
        queryWrapper.ne(Activity::getStatus, 3);
        
        // 按开始时间降序排序
        queryWrapper.orderByDesc(Activity::getStartTime);
        
        return page(page, queryWrapper);
    }
    
    @Override
    public Page<Activity> searchActivities(Integer current, Integer size, String keyword, Integer type) {
        Page<Activity> page = new Page<>(current, size);
        LambdaQueryWrapper<Activity> queryWrapper = new LambdaQueryWrapper<>();
        
        // 根据关键字搜索
        if (keyword != null && !keyword.isEmpty()) {
            queryWrapper.and(q -> 
                q.like(Activity::getTitle, keyword)
                .or()
                .like(Activity::getDescription, keyword)
                .or()
                .like(Activity::getLocation, keyword)
            );
        }
        
        // 根据类型筛选
        if (type != null) {
            queryWrapper.eq(Activity::getType, type);
        }
        
        // 只查询未取消的活动
        queryWrapper.ne(Activity::getStatus, 3);
        
        // 按开始时间降序排序
        queryWrapper.orderByDesc(Activity::getStartTime);
        
        return page(page, queryWrapper);
    }
    
    @Override
    public List<Activity> getLatestActivities(Integer limit) {
        LambdaQueryWrapper<Activity> queryWrapper = new LambdaQueryWrapper<>();
        
        // 只查询未结束的活动
        queryWrapper.in(Activity::getStatus, 0, 1);
        
        // 未来的活动
        LocalDateTime now = LocalDateTime.now();
        queryWrapper.ge(Activity::getStartTime, now);
        
        // 按开始时间升序排序
        queryWrapper.orderByAsc(Activity::getStartTime);
        
        // 限制数量
        Page<Activity> page = new Page<>(1, limit);
        page(page, queryWrapper);
        
        return page.getRecords();
    }
    
    @Override
    public boolean updateActivityRating(Long activityId) {
        // 查询活动评分
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getActivityId, activityId);
        
        List<ActivityRating> ratings = activityRatingMapper.selectList(queryWrapper);
        
        if (ratings.isEmpty()) {
            return false;
        }
        
        // 计算平均评分
        float totalRating = 0;
        for (ActivityRating rating : ratings) {
            totalRating += rating.getRating();
        }
        
        float averageRating = totalRating / ratings.size();
        
        // 更新活动评分
        Activity activity = getById(activityId);
        if (activity == null) {
            return false;
        }
        
        activity.setAverageRating(averageRating);
        return updateById(activity);
    }
} 