package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.VolunteerRegistration;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 志愿服务报名Mapper接口
 */
public interface VolunteerRegistrationMapper extends BaseMapper<VolunteerRegistration> {
    
    /**
     * 查询用户报名的所有志愿服务
     * @param userId 用户ID
     * @return 志愿服务报名列表
     */
    @Select("SELECT * FROM volunteer_registration WHERE user_id = #{userId} AND deleted = 0")
    List<VolunteerRegistration> selectByUserId(Long userId);
    
    /**
     * 查询志愿服务的所有报名记录
     * @param serviceId 服务ID
     * @return 志愿服务报名列表
     */
    @Select("SELECT * FROM volunteer_registration WHERE service_id = #{serviceId} AND deleted = 0")
    List<VolunteerRegistration> selectByServiceId(Long serviceId);
    
    /**
     * 统计用户的志愿服务工时
     * @param userId 用户ID
     * @return 志愿服务工时
     */
    @Select("SELECT SUM(actual_hours) FROM volunteer_registration WHERE user_id = #{userId} AND status = 1 AND deleted = 0")
    Float countHoursByUserId(Long userId);
} 