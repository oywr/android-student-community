package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 志愿服务报名实体类
 */
@Data
@TableName("volunteer_registration")
public class VolunteerRegistration {
    
    /**
     * 报名ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 服务ID
     */
    private Long serviceId;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 报名时间
     */
    private LocalDateTime registrationTime;
    
    /**
     * 报名状态 0-待审核 1-已通过 2-已拒绝 3-已取消
     */
    private Integer status;
    
    /**
     * 实际工时
     */
    private Float actualHours;
    
    /**
     * 提醒发送状态 0-未发送 1-已发送
     */
    private Integer reminderSent;
    
    /**
     * 签到状态 0-未签到 1-已签到
     */
    private Integer checkInStatus;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除 0-未删除 1-已删除
     */
    @TableLogic
    private Integer deleted;
} 