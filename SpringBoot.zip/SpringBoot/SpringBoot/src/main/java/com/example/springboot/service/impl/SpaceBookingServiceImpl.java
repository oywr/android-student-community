package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Space;
import com.example.springboot.entity.SpaceBooking;
import com.example.springboot.mapper.SpaceBookingMapper;
import com.example.springboot.mapper.SpaceMapper;
import com.example.springboot.service.SpaceBookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 空间预约服务实现类
 */
@Service
@RequiredArgsConstructor
public class SpaceBookingServiceImpl extends ServiceImpl<SpaceBookingMapper, SpaceBooking> implements SpaceBookingService {
    
    private final SpaceMapper spaceMapper;
    
    @Override
    @Transactional
    public boolean createBooking(SpaceBooking booking) {
        // 检查空间是否存在
        Space space = spaceMapper.selectById(booking.getSpaceId());
        if (space == null || space.getStatus() != 1) {
            return false;
        }
        
        // 检查时间冲突
        if (hasTimeConflict(booking)) {
            return false;
        }
        
        // 设置初始状态为待审核
        booking.setStatus(0);
        booking.setReminderSent(0);
        
        return save(booking);
    }
    
    @Override
    public Page<SpaceBooking> getUserBookings(Integer current, Integer size, Long userId) {
        Page<SpaceBooking> page = new Page<>(current, size);
        LambdaQueryWrapper<SpaceBooking> queryWrapper = new LambdaQueryWrapper<>();
        
        // 查询条件：用户ID
        queryWrapper.eq(SpaceBooking::getUserId, userId);
        
        // 按开始时间降序排序
        queryWrapper.orderByDesc(SpaceBooking::getStartTime);
        
        return page(page, queryWrapper);
    }
    
    @Override
    @Transactional
    public boolean updateBooking(SpaceBooking booking) {
        // 检查预约是否存在
        SpaceBooking existingBooking = getById(booking.getId());
        if (existingBooking == null) {
            return false;
        }
        
        // 检查用户权限
        if (!existingBooking.getUserId().equals(booking.getUserId())) {
            return false;
        }
        
        // 只能修改待审核的预约
        if (existingBooking.getStatus() != 0) {
            return false;
        }
        
        // 检查时间冲突（排除自身）
        if (hasTimeConflict(booking, booking.getId())) {
            return false;
        }
        
        return updateById(booking);
    }
    
    @Override
    @Transactional
    public boolean cancelBooking(Long id, Long userId) {
        // 检查预约是否存在
        SpaceBooking booking = getById(id);
        if (booking == null) {
            return false;
        }
        
        // 检查用户权限
        if (!booking.getUserId().equals(userId)) {
            return false;
        }
        
        // 只能取消待审核或已通过的预约
        if (booking.getStatus() != 0 && booking.getStatus() != 1) {
            return false;
        }
        
        // 设置状态为已取消
        booking.setStatus(3);
        
        return updateById(booking);
    }
    
    @Override
    public List<SpaceBooking> getSpaceBookingsByDate(Long spaceId, LocalDateTime startTime, LocalDateTime endTime) {
        LambdaQueryWrapper<SpaceBooking> queryWrapper = new LambdaQueryWrapper<>();
        
        // 查询条件：空间ID
        queryWrapper.eq(SpaceBooking::getSpaceId, spaceId);
        
        // 查询已通过的预约
        queryWrapper.eq(SpaceBooking::getStatus, 1);
        
        // 查询时间范围
        queryWrapper.and(w -> 
            w.between(SpaceBooking::getStartTime, startTime, endTime)
            .or()
            .between(SpaceBooking::getEndTime, startTime, endTime)
            .or()
            .and(sw -> sw.le(SpaceBooking::getStartTime, startTime)
                         .ge(SpaceBooking::getEndTime, endTime))
        );
        
        return list(queryWrapper);
    }
    
    /**
     * 检查时间冲突
     */
    private boolean hasTimeConflict(SpaceBooking booking) {
        return hasTimeConflict(booking, null);
    }
    
    /**
     * 检查时间冲突（可排除自身）
     */
    private boolean hasTimeConflict(SpaceBooking booking, Long excludeId) {
        LambdaQueryWrapper<SpaceBooking> queryWrapper = new LambdaQueryWrapper<>();
        
        // 查询条件：空间ID
        queryWrapper.eq(SpaceBooking::getSpaceId, booking.getSpaceId());
        
        // 排除自身
        if (excludeId != null) {
            queryWrapper.ne(SpaceBooking::getId, excludeId);
        }
        
        // 查询已通过的预约
        queryWrapper.eq(SpaceBooking::getStatus, 1);
        
        // 查询时间冲突
        queryWrapper.and(w -> 
            w.between(SpaceBooking::getStartTime, booking.getStartTime(), booking.getEndTime())
            .or()
            .between(SpaceBooking::getEndTime, booking.getStartTime(), booking.getEndTime())
            .or()
            .and(sw -> sw.le(SpaceBooking::getStartTime, booking.getStartTime())
                         .ge(SpaceBooking::getEndTime, booking.getEndTime()))
        );
        
        return count(queryWrapper) > 0;
    }
} 