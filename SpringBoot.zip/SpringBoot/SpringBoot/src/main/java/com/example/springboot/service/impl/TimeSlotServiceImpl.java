package com.example.springboot.service.impl;

import com.example.springboot.entity.SpaceBooking;
import com.example.springboot.service.TimeSlotService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 时间槽服务实现类
 */
@Service
public class TimeSlotServiceImpl implements TimeSlotService {

    @Override
    public List<Map<String, Object>> getAvailableTimes(Long spaceId, LocalDateTime dateTime, List<SpaceBooking> bookings) {
        // 可用时间段列表
        List<Map<String, Object>> availableTimes = new ArrayList<>();
        
        // 假设营业时间为早上8点到晚上10点，每个时间段为1小时
        LocalTime businessStart = LocalTime.of(8, 0);
        LocalTime businessEnd = LocalTime.of(22, 0);
        int timeSlotMinutes = 60;
        
        // 遍历所有时间段
        LocalTime currentTime = businessStart;
        while (currentTime.isBefore(businessEnd)) {
            LocalTime nextTime = currentTime.plusMinutes(timeSlotMinutes);
            
            // 判断当前时间段是否已被预约
            boolean isAvailable = true;
            for (SpaceBooking booking : bookings) {
                LocalTime bookingStart = booking.getStartTime().toLocalTime();
                LocalTime bookingEnd = booking.getEndTime().toLocalTime();
                
                // 如果当前时间段与已预约时间段有重叠，则不可用
                if (!(nextTime.isBefore(bookingStart) || currentTime.isAfter(bookingEnd))) {
                    isAvailable = false;
                    break;
                }
            }
            
            // 添加到结果列表
            Map<String, Object> timeSlot = new HashMap<>();
            timeSlot.put("startTime", currentTime.toString());
            timeSlot.put("endTime", nextTime.toString());
            timeSlot.put("available", isAvailable);
            availableTimes.add(timeSlot);
            
            // 移动到下一个时间段
            currentTime = nextTime;
        }
        
        return availableTimes;
    }
} 