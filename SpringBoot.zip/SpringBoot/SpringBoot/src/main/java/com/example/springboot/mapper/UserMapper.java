package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * 用户Mapper接口
 */
public interface UserMapper extends BaseMapper<User> {
    
    /**
     * 根据用户名查询用户
     * @param username 用户名
     * @return 用户对象
     */
    @Select("SELECT * FROM user WHERE username = #{username} AND deleted = 0")
    User selectByUsername(String username);
    
    /**
     * 根据手机号查询用户
     * @param phone 手机号
     * @return 用户对象
     */
    @Select("SELECT * FROM user WHERE phone = #{phone} AND deleted = 0")
    User selectByPhone(String phone);
    
    /**
     * 更新用户FCM令牌
     * @param userId 用户ID
     * @param fcmToken FCM令牌
     * @return 更新行数
     */
    @Update("UPDATE user SET fcm_token = #{fcmToken} WHERE id = #{userId}")
    int updateFcmToken(@Param("userId") Long userId, @Param("fcmToken") String fcmToken);
    
    /**
     * 根据用户ID查询FCM令牌
     * @param userId 用户ID
     * @return FCM令牌
     */
    @Select("SELECT fcm_token FROM user WHERE id = #{userId}")
    String selectFcmTokenByUserId(@Param("userId") Long userId);
} 