package com.example.springboot.exception;

/**
 * 服务异常类
 */
public class ServiceException extends RuntimeException {
    
    /**
     * 异常码
     */
    private Integer code;
    
    /**
     * 构造方法
     * @param message 异常信息
     */
    public ServiceException(String message) {
        super(message);
        this.code = 500;
    }
    
    /**
     * 构造方法
     * @param code 异常码
     * @param message 异常信息
     */
    public ServiceException(Integer code, String message) {
        super(message);
        this.code = code;
    }
    
    /**
     * 获取异常码
     * @return 异常码
     */
    public Integer getCode() {
        return code;
    }
} 