package com.example.springboot.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.CommunityPost;
import com.example.springboot.entity.PostComment;
import com.example.springboot.service.CommunityPostService;
import com.example.springboot.service.PostCommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 社区帖子控制器
 */
@RestController
@RequestMapping("/api/community/posts")
@RequiredArgsConstructor
public class CommunityPostController {
    
    private final CommunityPostService communityPostService;
    private final PostCommentService postCommentService;
    
    /**
     * 发布帖子
     */
    @PostMapping
    public Result<Map<String, Object>> createPost(
            @RequestBody CommunityPost post,
            @RequestAttribute("userId") Long userId) {
        
        // 设置用户ID
        post.setUserId(userId);
        
        boolean result = communityPostService.createPost(post);
        
        if (result) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", post.getId());
            return Result.success("发布成功", data);
        } else {
            return Result.error("发布失败");
        }
    }
    
    /**
     * 获取帖子列表
     */
    @GetMapping
    public Result<Page<CommunityPost>> listPosts(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer type) {
        
        Page<CommunityPost> page = communityPostService.listPosts(current, size, type);
        return Result.success(page);
    }
    
    /**
     * 获取帖子详情
     */
    @GetMapping("/{id}")
    public Result<CommunityPost> getPostById(@PathVariable Long id) {
        CommunityPost post = communityPostService.getById(id);
        
        if (post == null) {
            return Result.error("帖子不存在");
        }
        
        return Result.success(post);
    }
    
    /**
     * 发布评论
     */
    @PostMapping("/{id}/comments")
    public Result<Map<String, Object>> createComment(
            @PathVariable Long id,
            @RequestBody PostComment comment,
            @RequestAttribute("userId") Long userId) {
        
        // 设置帖子ID和用户ID
        comment.setPostId(id);
        comment.setUserId(userId);
        
        boolean result = postCommentService.createComment(comment);
        
        if (result) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", comment.getId());
            return Result.success("评论成功", data);
        } else {
            return Result.error("评论失败");
        }
    }
    
    /**
     * 获取评论列表
     */
    @GetMapping("/{id}/comments")
    public Result<Page<PostComment>> listComments(
            @PathVariable Long id,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size) {
        
        Page<PostComment> page = postCommentService.listComments(id, current, size);
        return Result.success(page);
    }
} 