package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.ActivityRegistration;

import java.util.List;

/**
 * 活动报名服务接口
 */
public interface ActivityRegistrationService extends IService<ActivityRegistration> {
    
    /**
     * 报名活动
     * @param registration 报名信息
     * @return 报名结果
     */
    boolean register(ActivityRegistration registration);
    
    /**
     * 取消报名
     * @param id 报名ID
     * @param userId 用户ID
     * @return 取消结果
     */
    boolean cancelRegistration(Long id, Long userId);
    
    /**
     * 活动签到
     * @param id 报名ID
     * @param userId 用户ID
     * @return 签到结果
     */
    boolean checkIn(Long id, Long userId);
    
    /**
     * 分页查询用户活动报名列表
     * @param current 当前页
     * @param size 每页大小
     * @param userId 用户ID
     * @return 分页结果
     */
    Page<ActivityRegistration> getUserRegistrations(int current, int size, Long userId);
    
    /**
     * 查询活动的所有报名记录
     * @param activityId 活动ID
     * @return 报名列表
     */
    List<ActivityRegistration> getByActivityId(Long activityId);
    
    /**
     * 处理活动提醒
     */
    void handleActivityReminders();
} 