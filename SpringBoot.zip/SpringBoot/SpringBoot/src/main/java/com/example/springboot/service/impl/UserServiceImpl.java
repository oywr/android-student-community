package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.common.PageResult;
import com.example.springboot.config.JwtConfig;
import com.example.springboot.entity.User;
import com.example.springboot.mapper.UserMapper;
import com.example.springboot.service.UserService;
import com.example.springboot.util.MD5Util;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 用户服务实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    
    private final JwtConfig jwtConfig;
    
    @Override
    public PageResult<User> page(int current, int size, String keyword) {
        Page<User> page = new Page<>(current, size);
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        
        // 关键字搜索
        if (StringUtils.hasText(keyword)) {
            queryWrapper.like(User::getUsername, keyword)
                    .or()
                    .like(User::getRealName, keyword)
                    .or()
                    .like(User::getPhone, keyword);
        }
        
        // 不返回已删除的用户
        queryWrapper.eq(User::getDeleted, 0);
        
        // 按创建时间降序排序
        queryWrapper.orderByDesc(User::getCreateTime);
        
        Page<User> resultPage = page(page, queryWrapper);
        return new PageResult<>(resultPage.getRecords(), resultPage.getTotal(), size, current);
    }
    
    @Override
    public String login(String username, String password) {
        log.info("尝试登录用户: {}", username);
        
        // 查询用户
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername, username);
        
        User user = getOne(queryWrapper);
        
        // 验证用户
        if (user == null) {
            log.error("登录失败：用户{}不存在", username);
            return null;
        }
        
        // 验证密码
        if (!MD5Util.verify(password, user.getPassword())) {
            log.error("登录失败：用户{}密码错误", username);
            return null;
        }
        
        // 验证状态
        if (user.getStatus() != 1) {
            log.error("登录失败：用户{}状态异常", username);
            return null;
        }
        
        try {
            // 记录JWT配置信息
            log.info("JWT配置：secret长度={}", jwtConfig.getSecret().length());
            log.info("JWT配置：expiration={}", jwtConfig.getExpiration());
            
            // 生成token
            Map<String, Object> claims = new HashMap<>();
            claims.put("userId", user.getId());
            claims.put("username", user.getUsername());
            String token = jwtConfig.generateToken(claims);
            
            if (token == null || token.isEmpty()) {
                log.error("生成token失败：token为空");
                // 尝试使用备用方式生成token
                log.info("尝试使用备用方式生成token");
                token = jwtConfig.generateToken(user.getId());
            }
            
            log.info("用户{}登录成功，生成token: {}", username, token);
            return token;
        } catch (Exception e) {
            log.error("生成token异常", e);
            return null;
        }
    }
    
    @Override
    @Transactional
    public boolean register(User user) {
        // 检查用户名是否已存在
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername, user.getUsername());
        
        if (count(queryWrapper) > 0) {
            return false;
        }
        
        // 加密密码
        user.setPassword(MD5Util.encrypt(user.getPassword()));
        
        // 设置默认状态
        user.setStatus(1);
        
        return save(user);
    }
    
    @Override
    public User getByUsername(String username) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername, username);
        
        return getOne(queryWrapper);
    }
    
    @Override
    public User getByPhone(String phone) {
        return baseMapper.selectByPhone(phone);
    }
    
    @Override
    @Transactional
    public boolean updatePassword(Long userId, String oldPassword, String newPassword) {
        // 查询用户
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        
        // 验证旧密码
        if (!MD5Util.verify(oldPassword, user.getPassword())) {
            return false;
        }
        
        // 更新密码
        User updateUser = new User();
        updateUser.setId(userId);
        updateUser.setPassword(MD5Util.encrypt(newPassword));
        
        return updateById(updateUser);
    }
    
    @Override
    @Transactional
    public boolean resetPassword(String username, String phone, String newPassword) {
        // 查询用户
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername, username);
        
        User user = getOne(queryWrapper);
        if (user == null) {
            return false;
        }
        
        // 验证手机号
        if (phone == null || !phone.equals(user.getPhone())) {
            return false;
        }
        
        // 更新密码
        user.setPassword(MD5Util.encrypt(newPassword));
        
        return updateById(user);
    }
    
    @Override
    @Transactional
    public boolean updateFcmToken(Long userId, String fcmToken) {
        User user = new User();
        user.setId(userId);
        user.setFcmToken(fcmToken);
        
        return updateById(user);
    }
    
    /**
     * 生成随机密码
     */
    private String generateRandomPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        
        for (int i = 0; i < 8; i++) {
            int index = random.nextInt(chars.length());
            sb.append(chars.charAt(index));
        }
        
        return sb.toString();
    }
} 