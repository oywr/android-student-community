package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 公共空间实体类
 */
@Data
@TableName("space")
public class Space {
    
    /**
     * 空间ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 空间名称
     */
    private String name;
    
    /**
     * 空间描述
     */
    private String description;
    
    /**
     * 空间位置
     */
    private String location;
    
    /**
     * 容纳人数
     */
    private Integer capacity;
    
    /**
     * 空间图片URL
     */
    private String imageUrl;
    
    /**
     * 空间类型
     */
    private Integer spaceType;
    
    /**
     * 空间状态 0-不可用 1-可用
     */
    private Integer status;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除 0-未删除 1-已删除
     */
    @TableLogic
    private Integer deleted;
} 