package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Feedback;

/**
 * 反馈服务接口
 */
public interface FeedbackService extends IService<Feedback> {
    
    /**
     * 提交反馈
     * @param feedback 反馈信息
     * @return 是否成功
     */
    boolean submit(Feedback feedback);
    
    /**
     * 获取用户反馈列表
     * @param current 当前页
     * @param size 每页大小
     * @param userId 用户ID
     * @return 反馈分页
     */
    Page<Feedback> getUserFeedbacks(Integer current, Integer size, Long userId);
} 