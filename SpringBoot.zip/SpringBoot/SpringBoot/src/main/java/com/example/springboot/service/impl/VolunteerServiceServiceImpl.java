package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.VolunteerService;
import com.example.springboot.mapper.VolunteerServiceMapper;
import com.example.springboot.service.VolunteerServiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 志愿服务服务实现类
 */
@Service
@RequiredArgsConstructor
public class VolunteerServiceServiceImpl extends ServiceImpl<VolunteerServiceMapper, VolunteerService> implements VolunteerServiceService {
    
    @Override
    public Page<VolunteerService> listServices(int current, int size) {
        Page<VolunteerService> page = new Page<>(current, size);
        
        LambdaQueryWrapper<VolunteerService> queryWrapper = new LambdaQueryWrapper<>();
        // 查询未取消的服务
        queryWrapper.ne(VolunteerService::getStatus, 3);
        
        // 按时间降序排序
        queryWrapper.orderByDesc(VolunteerService::getCreateTime);
        
        return baseMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public List<VolunteerService> getLatestServices(int limit) {
        LambdaQueryWrapper<VolunteerService> queryWrapper = new LambdaQueryWrapper<>();
        // 查询未结束和未取消的服务
        queryWrapper.in(VolunteerService::getStatus, 0, 1);
        
        // 按时间降序排序
        queryWrapper.orderByDesc(VolunteerService::getCreateTime);
        
        // 限制数量
        queryWrapper.last("LIMIT " + limit);
        
        return baseMapper.selectList(queryWrapper);
    }
    
    /**
     * 定时更新志愿服务状态
     * 每小时执行一次
     */
    //@Scheduled(fixedRate = 3600000)
    public void updateServiceStatus() {
        LocalDateTime now = LocalDateTime.now();
        
        // 更新未开始的服务
        LambdaQueryWrapper<VolunteerService> startQueryWrapper = new LambdaQueryWrapper<>();
        startQueryWrapper.eq(VolunteerService::getStatus, 0); // 未开始的服务
        startQueryWrapper.le(VolunteerService::getStartTime, now); // 开始时间已到
        
        List<VolunteerService> toStartServices = baseMapper.selectList(startQueryWrapper);
        for (VolunteerService service : toStartServices) {
            VolunteerService updateService = new VolunteerService();
            updateService.setId(service.getId());
            updateService.setStatus(1); // 设置为进行中
            updateById(updateService);
        }
        
        // 更新已结束的服务
        LambdaQueryWrapper<VolunteerService> endQueryWrapper = new LambdaQueryWrapper<>();
        endQueryWrapper.eq(VolunteerService::getStatus, 1); // 进行中的服务
        endQueryWrapper.le(VolunteerService::getEndTime, now); // 结束时间已到
        
        List<VolunteerService> toEndServices = baseMapper.selectList(endQueryWrapper);
        for (VolunteerService service : toEndServices) {
            VolunteerService updateService = new VolunteerService();
            updateService.setId(service.getId());
            updateService.setStatus(2); // 设置为已结束
            updateById(updateService);
        }
    }
} 