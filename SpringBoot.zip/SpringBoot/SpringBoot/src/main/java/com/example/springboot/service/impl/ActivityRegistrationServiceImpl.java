package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Activity;
import com.example.springboot.entity.ActivityRegistration;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.ActivityMapper;
import com.example.springboot.mapper.ActivityRegistrationMapper;
import com.example.springboot.service.ActivityRegistrationService;
import com.example.springboot.service.ActivityService;
import com.example.springboot.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 活动报名服务实现类
 */
@Service
@RequiredArgsConstructor
public class ActivityRegistrationServiceImpl extends ServiceImpl<ActivityRegistrationMapper, ActivityRegistration> implements ActivityRegistrationService {
    
    private final ActivityMapper activityMapper;
    private final ActivityService activityService;
    private final NotificationService notificationService;
    
    @Override
    @Transactional
    public boolean register(ActivityRegistration registration) {
        // 查询活动信息
        Activity activity = activityMapper.selectById(registration.getActivityId());
        if (activity == null) {
            throw new ServiceException("活动不存在");
        }
        
        if (activity.getStatus() == 2 || activity.getStatus() == 3) {
            throw new ServiceException("活动已结束或已取消");
        }
        
        if (activity.getCapacity() != null && activity.getRegisteredCount() >= activity.getCapacity()) {
            throw new ServiceException("活动报名人数已满");
        }
        
        // 检查用户是否有活跃的报名记录（非取消状态）
        LambdaQueryWrapper<ActivityRegistration> activeQuery = new LambdaQueryWrapper<>();
        activeQuery.eq(ActivityRegistration::getActivityId, registration.getActivityId());
        activeQuery.eq(ActivityRegistration::getUserId, registration.getUserId());
        activeQuery.ne(ActivityRegistration::getStatus, 3); // 非取消状态
        
        Long activeCount = baseMapper.selectCount(activeQuery);
        if (activeCount > 0) {
            throw new ServiceException("您已经报名该活动");
        }
        
        boolean result = false;
        
        // 检查是否存在已取消的报名记录
        LambdaQueryWrapper<ActivityRegistration> canceledQuery = new LambdaQueryWrapper<>();
        canceledQuery.eq(ActivityRegistration::getActivityId, registration.getActivityId());
        canceledQuery.eq(ActivityRegistration::getUserId, registration.getUserId());
        canceledQuery.eq(ActivityRegistration::getStatus, 3); // 已取消状态
        
        ActivityRegistration canceledRegistration = getOne(canceledQuery);
        
        if (canceledRegistration != null) {
            // 如果存在已取消的报名记录，则更新该记录
            canceledRegistration.setRegistrationTime(LocalDateTime.now());
            canceledRegistration.setStatus(1); // 设置为已通过
            canceledRegistration.setReminderSent(0);
            canceledRegistration.setCheckInStatus(0);
            result = updateById(canceledRegistration);
            
            // 更新registration对象的ID，以便后续使用
            registration.setId(canceledRegistration.getId());
        } else {
            // 创建新的报名记录
            registration.setRegistrationTime(LocalDateTime.now());
            registration.setStatus(1); // 设置为已通过
            registration.setReminderSent(0);
            registration.setCheckInStatus(0);
            result = save(registration);
        }
        
        // 更新活动报名人数
        if (result) {
            activity.setRegisteredCount(activity.getRegisteredCount() + 1);
            activityMapper.updateById(activity);
            
            // 创建通知
            notificationService.createActivityNotification(
                registration.getUserId(),
                activity.getId(),
                "活动报名成功",
                "您已成功报名" + activity.getTitle() + "活动，请准时参加。"
            );
        }
        
        return result;
    }
    
    @Override
    @Transactional
    public boolean cancelRegistration(Long id, Long userId) {
        // 查询报名信息
        LambdaQueryWrapper<ActivityRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRegistration::getActivityId, id);
        queryWrapper.eq(ActivityRegistration::getUserId, userId);
        
        ActivityRegistration registration = getOne(queryWrapper);
        if (registration == null) {
            throw new ServiceException("报名记录不存在");
        }
        
        if (registration.getStatus() == 3) {
            throw new ServiceException("已取消报名");
        }
        
        // 查询活动信息
        Activity activity = activityMapper.selectById(registration.getActivityId());
        if (activity == null) {
            throw new ServiceException("活动不存在");
        }
        
        if (activity.getStatus() == 2) {
            throw new ServiceException("活动已结束，无法取消报名");
        }
        
        // 设置状态为已取消
        registration.setStatus(3);

        boolean result = updateById(registration);
        // 更新活动报名人数
        if (result) {
            activity.setRegisteredCount(activity.getRegisteredCount() - 1);
            activityMapper.updateById(activity);
            // 创建通知
            notificationService.createActivityNotification(
                userId,
                activity.getId(),
                "取消活动报名",
                "您已取消" + activity.getTitle() + "活动的报名。"
            );
        }
        
        return result;
    }
    
    @Override
    public boolean checkIn(Long id, Long userId) {
        // 查询报名信息
        LambdaQueryWrapper<ActivityRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRegistration::getActivityId, id);
        queryWrapper.eq(ActivityRegistration::getUserId, userId);
        
        ActivityRegistration registration = getOne(queryWrapper);
        if (registration == null) {
            throw new ServiceException("报名记录不存在");
        }
        
        if (registration.getStatus() != 1) {
            throw new ServiceException("报名未通过，无法签到");
        }
        
        if (registration.getCheckInStatus() == 1) {
            throw new ServiceException("已签到");
        }

        registration.setCheckInStatus(1);
        
        boolean result = updateById(registration);
        
        // 创建通知
        if (result) {
            Activity activity = activityMapper.selectById(registration.getActivityId());
            notificationService.createActivityNotification(
                userId,
                activity.getId(),
                "签到成功",
                "您已成功签到" + activity.getTitle() + "活动。"
            );
        }
        
        return result;
    }
    
    @Override
    public Page<ActivityRegistration> getUserRegistrations(int current, int size, Long userId) {
        Page<ActivityRegistration> page = new Page<>(current, size);
        
        LambdaQueryWrapper<ActivityRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRegistration::getUserId, userId);
        queryWrapper.orderByDesc(ActivityRegistration::getRegistrationTime);
        
        return baseMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public List<ActivityRegistration> getByActivityId(Long activityId) {
        return baseMapper.selectByActivityId(activityId);
    }
    
    @Override
    @Scheduled(fixedRate = 60000) // 每分钟执行一次
    public void handleActivityReminders() {
        LocalDateTime now = LocalDateTime.now();
        
        // 查询所有即将开始的活动（1小时内）
        LambdaQueryWrapper<Activity> activityQuery = new LambdaQueryWrapper<>();
        activityQuery.eq(Activity::getStatus, 0); // 未开始的活动
        activityQuery.le(Activity::getStartTime, now.plusHours(1));
        activityQuery.gt(Activity::getStartTime, now);
        
        List<Activity> upcomingActivities = activityMapper.selectList(activityQuery);
        
        for (Activity activity : upcomingActivities) {
            // 查询该活动的所有已通过报名且未发送提醒的记录
            LambdaQueryWrapper<ActivityRegistration> registrationQuery = new LambdaQueryWrapper<>();
            registrationQuery.eq(ActivityRegistration::getActivityId, activity.getId());
            registrationQuery.eq(ActivityRegistration::getStatus, 1);
            registrationQuery.eq(ActivityRegistration::getReminderSent, 0);
            
            List<ActivityRegistration> registrations = baseMapper.selectList(registrationQuery);
            
            for (ActivityRegistration registration : registrations) {
                // 发送提醒通知
                notificationService.createActivityNotification(
                    registration.getUserId(),
                    activity.getId(),
                    "活动即将开始",
                    "您报名的" + activity.getTitle() + "活动将于" + activity.getStartTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) + "开始，请准时参加。"
                );
                
                // 标记提醒已发送
                ActivityRegistration updateRegistration = new ActivityRegistration();
                updateRegistration.setId(registration.getId());
                updateRegistration.setReminderSent(1);
                updateById(updateRegistration);
            }
            
            // 更新活动状态
            if (activity.getStartTime().isBefore(now)) {
                Activity updateActivity = new Activity();
                updateActivity.setId(activity.getId());
                updateActivity.setStatus(1); // 设置为进行中
                activityService.updateById(updateActivity);
            }
        }
        
        // 处理已结束的活动
        LambdaQueryWrapper<Activity> endedActivityQuery = new LambdaQueryWrapper<>();
        endedActivityQuery.eq(Activity::getStatus, 1); // 进行中的活动
        endedActivityQuery.lt(Activity::getEndTime, now);
        
        List<Activity> endedActivities = activityMapper.selectList(endedActivityQuery);
        
        for (Activity activity : endedActivities) {
            // 更新活动状态为已结束
            Activity updateActivity = new Activity();
            updateActivity.setId(activity.getId());
            updateActivity.setStatus(2);
            activityService.updateById(updateActivity);
        }
    }
} 