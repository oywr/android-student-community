package com.example.springboot.common;

import lombok.Data;

/**
 * 通用返回结果类
 */
@Data
public class Result<T> {
    
    /**
     * 状态码
     */
    private Integer code;
    
    /**
     * 提示信息
     */
    private String message;
    
    /**
     * 返回数据
     */
    private T data;
    
    /**
     * 成功结果
     * @param data 数据
     * @param <T> 数据类型
     * @return 返回结果
     */
    public static <T> Result<T> success(T data) {
        Result<T> result = new Result<>();
        result.setCode(ResultCode.SUCCESS);
        result.setMessage("操作成功");
        result.setData(data);
        return result;
    }
    
    /**
     * 成功结果
     * @param message 提示信息
     * @param data 数据
     * @param <T> 数据类型
     * @return 返回结果
     */
    public static <T> Result<T> success(String message, T data) {
        Result<T> result = new Result<>();
        result.setCode(ResultCode.SUCCESS);
        result.setMessage(message);
        result.setData(data);
        return result;
    }
    
    /**
     * 失败结果
     * @param message 错误信息
     * @param <T> 数据类型
     * @return 返回结果
     */
    public static <T> Result<T> error(String message) {
        Result<T> result = new Result<>();
        result.setCode(ResultCode.ERROR);
        result.setMessage(message);
        return result;
    }
    
    /**
     * 失败结果
     * @param code 错误码
     * @param message 错误信息
     * @param <T> 数据类型
     * @return 返回结果
     */
    public static <T> Result<T> error(Integer code, String message) {
        Result<T> result = new Result<>();
        result.setCode(code);
        result.setMessage(message);
        return result;
    }
} 