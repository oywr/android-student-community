package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.SpaceBooking;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 空间预约服务接口
 */
public interface SpaceBookingService extends IService<SpaceBooking> {
    
    /**
     * 创建预约
     * @param booking 预约信息
     * @return 是否成功
     */
    boolean createBooking(SpaceBooking booking);
    
    /**
     * 获取用户预约列表
     * @param current 当前页
     * @param size 每页大小
     * @param userId 用户ID
     * @return 预约分页
     */
    Page<SpaceBooking> getUserBookings(Integer current, Integer size, Long userId);
    
    /**
     * 更新预约
     * @param booking 预约信息
     * @return 是否成功
     */
    boolean updateBooking(SpaceBooking booking);
    
    /**
     * 取消预约
     * @param id 预约ID
     * @param userId 用户ID
     * @return 是否成功
     */
    boolean cancelBooking(Long id, Long userId);
    
    /**
     * 根据日期获取空间预约
     * @param spaceId 空间ID
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 预约列表
     */
    List<SpaceBooking> getSpaceBookingsByDate(Long spaceId, LocalDateTime startTime, LocalDateTime endTime);
} 