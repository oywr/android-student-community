package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.ActivityRegistration;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 活动报名Mapper接口
 */
public interface ActivityRegistrationMapper extends BaseMapper<ActivityRegistration> {
    
    /**
     * 查询用户报名的所有活动
     * @param userId 用户ID
     * @return 活动报名列表
     */
    @Select("SELECT * FROM activity_registration WHERE user_id = #{userId} AND deleted = 0")
    List<ActivityRegistration> selectByUserId(Long userId);
    
    /**
     * 查询活动的所有报名记录
     * @param activityId 活动ID
     * @return 活动报名列表
     */
    @Select("SELECT * FROM activity_registration WHERE activity_id = #{activityId} AND deleted = 0")
    List<ActivityRegistration> selectByActivityId(Long activityId);
} 