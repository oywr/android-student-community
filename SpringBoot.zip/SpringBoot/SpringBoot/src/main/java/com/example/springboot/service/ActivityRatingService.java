package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.ActivityRating;

import java.util.List;

/**
 * 活动评价服务接口
 */
public interface ActivityRatingService extends IService<ActivityRating> {
    
    /**
     * 评价活动
     * @param rating 评价信息
     * @return 评价结果
     */
    boolean rateActivity(ActivityRating rating);
    
    /**
     * 删除评价
     * @param id 评价ID
     * @param userId 用户ID
     * @return 删除结果
     */
    boolean deleteRating(Long id, Long userId);
    
    /**
     * 分页查询活动评价列表
     * @param current 当前页
     * @param size 每页大小
     * @param activityId 活动ID
     * @return 分页结果
     */
    Page<ActivityRating> getActivityRatings(int current, int size, Long activityId);
    
    /**
     * 获取用户对活动的评价
     * @param activityId 活动ID
     * @param userId 用户ID
     * @return 评价信息
     */
    ActivityRating getUserRating(Long activityId, Long userId);
} 