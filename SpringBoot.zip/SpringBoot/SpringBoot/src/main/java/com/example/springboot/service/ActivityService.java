package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Activity;

import java.util.List;

/**
 * 活动服务接口
 */
public interface ActivityService extends IService<Activity> {
    
    /**
     * 获取活动列表
     * @param current 当前页
     * @param size 每页大小
     * @param type 活动类型
     * @return 活动分页
     */
    Page<Activity> listActivities(Integer current, Integer size, Integer type);
    
    /**
     * 搜索活动
     * @param current 当前页
     * @param size 每页大小
     * @param keyword 关键字
     * @param type 活动类型
     * @return 活动分页
     */
    Page<Activity> searchActivities(Integer current, Integer size, String keyword, Integer type);
    
    /**
     * 获取最新活动
     * @param limit 限制数量
     * @return 活动列表
     */
    List<Activity> getLatestActivities(Integer limit);
    
    /**
     * 更新活动评分
     * @param activityId 活动ID
     * @return 更新结果
     */
    boolean updateActivityRating(Long activityId);
} 