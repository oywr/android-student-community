package com.example.springboot;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.springboot.mapper")
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        System.out.println("=================================================");
        System.out.println("🚀 恭喜您！Spring Boot 应用已成功启动");
        System.out.println("🔥 开发者：请访问 http://localhost:8080 开始使用");
        System.out.println("=================================================");
        //下载好了再叫我，@我就行，到时候再远程，我也不知为啥你下载这么慢
    }

}
