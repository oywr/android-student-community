package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Space;
import com.example.springboot.entity.SpaceBooking;
import com.example.springboot.mapper.SpaceMapper;
import com.example.springboot.service.SpaceBookingService;
import com.example.springboot.service.SpaceService;
import com.example.springboot.service.TimeSlotService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 空间服务实现类
 */
@Service
@RequiredArgsConstructor
public class SpaceServiceImpl extends ServiceImpl<SpaceMapper, Space> implements SpaceService {
    
    private final TimeSlotService timeSlotService;
    
    @Override
    public Page<Space> listSpaces(Integer current, Integer size, Integer spaceType) {
        Page<Space> page = new Page<>(current, size);
        LambdaQueryWrapper<Space> queryWrapper = new LambdaQueryWrapper<>();
        
        // 只查询可用的空间
        queryWrapper.eq(Space::getStatus, 1);
        
        // 如果指定了类型，添加类型筛选条件
        if (spaceType != null) {
            queryWrapper.eq(Space::getSpaceType, spaceType);
        }
        
        // 按ID升序排序
        queryWrapper.orderByAsc(Space::getId);
        
        return page(page, queryWrapper);
    }
    
    @Override
    public List<Map<String, Object>> getAvailableTimes(Long spaceId, LocalDateTime dateTime, List<SpaceBooking> bookings) {
        return timeSlotService.getAvailableTimes(spaceId, dateTime, bookings);
    }
} 