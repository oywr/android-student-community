package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Activity;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 活动Mapper接口
 */
public interface ActivityMapper extends BaseMapper<Activity> {
    
    /**
     * 查询最新的活动列表
     * @param limit 限制数量
     * @return 活动列表
     */
    @Select("SELECT * FROM activity WHERE status IN (0, 1) AND deleted = 0 ORDER BY create_time DESC LIMIT #{limit}")
    List<Activity> selectLatestActivities(Integer limit);
} 