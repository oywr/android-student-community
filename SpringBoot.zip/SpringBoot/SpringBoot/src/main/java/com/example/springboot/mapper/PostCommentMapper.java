package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.PostComment;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 帖子评论Mapper接口
 */
public interface PostCommentMapper extends BaseMapper<PostComment> {
    
    /**
     * 查询帖子的所有评论
     * @param postId 帖子ID
     * @return 评论列表
     */
    @Select("SELECT * FROM post_comment WHERE post_id = #{postId} AND status = 1 AND deleted = 0 ORDER BY create_time ASC")
    List<PostComment> selectByPostId(Long postId);
    
    /**
     * 查询评论的所有回复
     * @param parentId 父评论ID
     * @return 回复列表
     */
    @Select("SELECT * FROM post_comment WHERE parent_id = #{parentId} AND status = 1 AND deleted = 0 ORDER BY create_time ASC")
    List<PostComment> selectByParentId(Long parentId);
} 