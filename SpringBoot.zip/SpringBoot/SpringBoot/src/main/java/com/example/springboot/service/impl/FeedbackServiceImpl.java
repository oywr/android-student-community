package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Feedback;
import com.example.springboot.mapper.FeedbackMapper;
import com.example.springboot.service.FeedbackService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 反馈服务实现类
 */
@Service
public class FeedbackServiceImpl extends ServiceImpl<FeedbackMapper, Feedback> implements FeedbackService {
    
    @Override
    @Transactional
    public boolean submit(Feedback feedback) {
        // 设置初始状态为未处理
        feedback.setStatus(0);
        return save(feedback);
    }
    
    @Override
    public Page<Feedback> getUserFeedbacks(Integer current, Integer size, Long userId) {
        Page<Feedback> page = new Page<>(current, size);
        LambdaQueryWrapper<Feedback> queryWrapper = new LambdaQueryWrapper<>();
        
        // 查询条件：用户ID
        queryWrapper.eq(Feedback::getUserId, userId);
        
        // 按创建时间降序排序
        queryWrapper.orderByDesc(Feedback::getCreateTime);
        
        return page(page, queryWrapper);
    }
} 