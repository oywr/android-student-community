package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.PostComment;

/**
 * 帖子评论服务接口
 */
public interface PostCommentService extends IService<PostComment> {
    
    /**
     * 创建评论
     * @param comment 评论信息
     * @return 是否成功
     */
    boolean createComment(PostComment comment);
    
    /**
     * 获取帖子评论列表
     * @param postId 帖子ID
     * @param current 当前页
     * @param size 每页大小
     * @return 评论分页
     */
    Page<PostComment> listComments(Long postId, Integer current, Integer size);
} 