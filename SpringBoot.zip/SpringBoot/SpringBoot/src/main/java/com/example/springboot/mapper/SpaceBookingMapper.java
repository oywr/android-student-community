package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.SpaceBooking;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 空间预约Mapper接口
 */
public interface SpaceBookingMapper extends BaseMapper<SpaceBooking> {
    
    /**
     * 查询用户所有未完成的预约
     * @param userId 用户ID
     * @return 预约列表
     */
    @Select("SELECT * FROM space_booking WHERE user_id = #{userId} AND status = 1 AND start_time > NOW() AND deleted = 0")
    List<SpaceBooking> selectPendingBookings(Long userId);
} 