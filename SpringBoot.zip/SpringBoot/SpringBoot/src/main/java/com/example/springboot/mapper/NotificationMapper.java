package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Notification;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 通知Mapper接口
 */
public interface NotificationMapper extends BaseMapper<Notification> {
    
    /**
     * 查询用户的所有未读通知
     * @param userId 用户ID
     * @return 通知列表
     */
    @Select("SELECT * FROM notification WHERE user_id = #{userId} AND read_status = 0 AND deleted = 0 ORDER BY create_time DESC")
    List<Notification> selectUnreadByUserId(Long userId);
    
    /**
     * 查询用户的所有通知
     * @param userId 用户ID
     * @return 通知列表
     */
    @Select("SELECT * FROM notification WHERE user_id = #{userId} AND deleted = 0 ORDER BY create_time DESC")
    List<Notification> selectByUserId(Long userId);
    
    /**
     * 统计用户未读通知数量
     * @param userId 用户ID
     * @return 未读通知数量
     */
    @Select("SELECT COUNT(*) FROM notification WHERE user_id = #{userId} AND read_status = 0 AND deleted = 0")
    Integer countUnreadByUserId(Long userId);
    
    /**
     * 将用户所有未读通知标记为已读
     * @param userId 用户ID
     * @return 更新行数
     */
    @Update("UPDATE notification SET read_status = 1 WHERE user_id = #{userId} AND read_status = 0")
    int markAllAsRead(Long userId);
    
    /**
     * 将指定通知标记为已读
     * @param id 通知ID
     * @param userId 用户ID
     * @return 更新行数
     */
    @Update("UPDATE notification SET read_status = 1 WHERE id = #{id} AND user_id = #{userId}")
    int markAsRead(@Param("id") Long id, @Param("userId") Long userId);
} 