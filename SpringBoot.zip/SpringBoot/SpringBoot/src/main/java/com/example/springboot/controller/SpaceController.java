package com.example.springboot.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.Space;
import com.example.springboot.entity.SpaceBooking;
import com.example.springboot.service.SpaceBookingService;
import com.example.springboot.service.SpaceService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 空间预约控制器
 */
@RestController
@RequestMapping("/api/space")
@RequiredArgsConstructor
public class SpaceController {
    
    private final SpaceService spaceService;
    private final SpaceBookingService spaceBookingService;
    
    /**
     * 获取空间列表
     */
    @GetMapping("/list")
    public Result<Page<Space>> list(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer spaceType) {
        
        Page<Space> page = spaceService.listSpaces(current, size, spaceType);
        return Result.success(page);
    }
    
    /**
     * 获取空间详情
     */
    @GetMapping("/{id}")
    public Result<Space> getById(@PathVariable Long id) {
        Space space = spaceService.getById(id);
        
        if (space == null) {
            return Result.error("空间不存在");
        }
        
        return Result.success(space);
    }
    
    /**
     * 获取可用时间段
     */
    @GetMapping("/time-slots")
    public Result<List<Map<String, Object>>> getAvailableTimes(
            @RequestParam Long spaceId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
        
        // 设置查询日期的起始和结束时间
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(23, 59, 59);
        
        // 查询该空间在指定日期的所有预约
        List<SpaceBooking> bookings = spaceBookingService.getSpaceBookingsByDate(spaceId, startOfDay, endOfDay);
        
        // 获取可用时间段
        List<Map<String, Object>> availableTimes = spaceService.getAvailableTimes(spaceId, startOfDay, bookings);
        
        return Result.success(availableTimes);
    }
    
    /**
     * 预约请求DTO
     */
    @Data
    public static class BookingRequest {
        private Long spaceId;
        private String date;
        private String startTime;
        private String endTime;
        private Integer peopleCount;
        private String purpose;
    }
    
    /**
     * 创建预约
     */
    @PostMapping("/booking")
    public Result<Map<String, Object>> createBooking(
            @RequestBody BookingRequest request,
            @RequestAttribute("userId") Long userId) {
        
        try {
            // 解析日期和时间
            LocalDate bookingDate = LocalDate.parse(request.getDate());
            
            // 构建完整的日期时间
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
            
            // 处理时间格式，支持HH:mm和HH:mm:ss两种格式
            String startTimeStr = request.getStartTime();
            String endTimeStr = request.getEndTime();
            
            // 如果时间字符串包含日期部分，提取时间部分
            if (startTimeStr.contains(" ")) {
                startTimeStr = startTimeStr.split(" ")[1];
            }
            if (endTimeStr.contains(" ")) {
                endTimeStr = endTimeStr.split(" ")[1];
            }
            
            // 确保时间格式为HH:mm:ss
            if (!startTimeStr.contains(":")) {
                throw new IllegalArgumentException("Invalid time format: " + startTimeStr);
            }
            if (startTimeStr.split(":").length == 2) {
                startTimeStr = startTimeStr + ":00";
            }
            
            if (!endTimeStr.contains(":")) {
                throw new IllegalArgumentException("Invalid time format: " + endTimeStr);
            }
            if (endTimeStr.split(":").length == 2) {
                endTimeStr = endTimeStr + ":00";
            }
            
            // 解析时间
            LocalTime startTime = LocalTime.parse(startTimeStr, timeFormatter);
            LocalTime endTime = LocalTime.parse(endTimeStr, timeFormatter);
            
            // 创建SpaceBooking对象
            SpaceBooking booking = new SpaceBooking();
            booking.setSpaceId(request.getSpaceId());
            booking.setUserId(userId);
            booking.setStartTime(LocalDateTime.of(bookingDate, startTime));
            booking.setEndTime(LocalDateTime.of(bookingDate, endTime));
            booking.setPeopleCount(request.getPeopleCount());
            booking.setPurpose(request.getPurpose());
            
            // 创建预约
            boolean result = spaceBookingService.createBooking(booking);
            
            if (result) {
                Map<String, Object> data = new HashMap<>();
                data.put("id", booking.getId());
                return Result.success("预约成功", data);
            } else {
                return Result.error("预约失败");
            }
        } catch (Exception e) {
            return Result.error("预约失败: " + e.getMessage());
        }
    }
    
    /**
     * 获取预约列表
     */
    @GetMapping("/booking/user")
    public Result<Page<SpaceBooking>> listBookings(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestAttribute("userId") Long userId) {
        
        Page<SpaceBooking> page = spaceBookingService.getUserBookings(current, size, userId);
        return Result.success(page);
    }
    
    /**
     * 更新预约请求DTO
     */
    @Data
    public static class UpdateBookingRequest {
        private Long id;
        private String date;
        private String startTime;
        private String endTime;
        private Integer peopleCount;
        private String purpose;
    }
    
    /**
     * 修改预约
     */
    @PutMapping("/booking/{id}")
    public Result<Void> updateBooking(
            @PathVariable Long id,
            @RequestBody UpdateBookingRequest request,
            @RequestAttribute("userId") Long userId) {
        
        try {
            // 解析日期和时间
            LocalDate bookingDate = LocalDate.parse(request.getDate());
            
            // 构建完整的日期时间
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
            
            // 处理时间格式，支持HH:mm和HH:mm:ss两种格式
            String startTimeStr = request.getStartTime();
            String endTimeStr = request.getEndTime();
            
            // 如果时间字符串包含日期部分，提取时间部分
            if (startTimeStr.contains(" ")) {
                startTimeStr = startTimeStr.split(" ")[1];
            }
            if (endTimeStr.contains(" ")) {
                endTimeStr = endTimeStr.split(" ")[1];
            }
            
            // 确保时间格式为HH:mm:ss
            if (!startTimeStr.contains(":")) {
                throw new IllegalArgumentException("Invalid time format: " + startTimeStr);
            }
            if (startTimeStr.split(":").length == 2) {
                startTimeStr = startTimeStr + ":00";
            }
            
            if (!endTimeStr.contains(":")) {
                throw new IllegalArgumentException("Invalid time format: " + endTimeStr);
            }
            if (endTimeStr.split(":").length == 2) {
                endTimeStr = endTimeStr + ":00";
            }
            
            // 解析时间
            LocalTime startTime = LocalTime.parse(startTimeStr, timeFormatter);
            LocalTime endTime = LocalTime.parse(endTimeStr, timeFormatter);
            
            // 创建SpaceBooking对象
            SpaceBooking booking = new SpaceBooking();
            booking.setId(id);
            booking.setUserId(userId);
            booking.setStartTime(LocalDateTime.of(bookingDate, startTime));
            booking.setEndTime(LocalDateTime.of(bookingDate, endTime));
            booking.setPeopleCount(request.getPeopleCount());
            booking.setPurpose(request.getPurpose());
            
            // 更新预约
            boolean result = spaceBookingService.updateBooking(booking);
            
            return result ? Result.success("修改成功", null) : Result.error("修改失败");
        } catch (Exception e) {
            return Result.error("修改失败: " + e.getMessage());
        }
    }
    
    /**
     * 取消预约
     */
    @PutMapping("/booking/{id}/cancel")
    public Result<Void> cancelBooking(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = spaceBookingService.cancelBooking(id, userId);
        
        return result ? Result.success("取消成功", null) : Result.error("取消失败");
    }
} 