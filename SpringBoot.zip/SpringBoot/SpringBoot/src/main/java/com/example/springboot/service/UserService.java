package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.common.PageResult;
import com.example.springboot.entity.User;

/**
 * 用户服务接口
 */
public interface UserService extends IService<User> {
    
    /**
     * 分页查询用户
     * @param current 当前页
     * @param size 每页大小
     * @param keyword 搜索关键词
     * @return 分页结果
     */
    PageResult<User> page(int current, int size, String keyword);
    
    /**
     * 用户登录
     * @param username 用户名
     * @param password 密码
     * @return JWT令牌
     */
    String login(String username, String password);
    
    /**
     * 用户注册
     * @param user 用户信息
     * @return 是否成功
     */
    boolean register(User user);
    
    /**
     * 根据用户名查询用户
     * @param username 用户名
     * @return 用户信息
     */
    User getByUsername(String username);
    
    /**
     * 根据手机号查询用户
     * @param phone 手机号
     * @return 用户对象
     */
    User getByPhone(String phone);
    
    /**
     * 修改密码
     * @param userId 用户ID
     * @param oldPassword 原密码
     * @param newPassword 新密码
     * @return 是否成功
     */
    boolean updatePassword(Long userId, String oldPassword, String newPassword);
    
    /**
     * 更新FCM令牌
     * @param userId 用户ID
     * @param fcmToken FCM令牌
     * @return 是否成功
     */
    boolean updateFcmToken(Long userId, String fcmToken);
    
    /**
     * 忘记密码时重置密码（需要用户名和手机号验证）
     * @param username 用户名
     * @param phone 手机号
     * @param newPassword 新密码
     * @return 是否成功
     */
    boolean resetPassword(String username, String phone, String newPassword);
} 