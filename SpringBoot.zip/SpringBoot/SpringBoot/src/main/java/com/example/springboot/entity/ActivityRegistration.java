package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 活动报名实体类
 */
@Data
@TableName("activity_registration")
public class ActivityRegistration {
    
    /**
     * 报名ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    
    /**
     * 活动ID
     */
    private Long activityId;
    
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 报名时间
     */
    private LocalDateTime registrationTime;
    
    /**
     * 报名状态 0-待审核 1-已通过 2-已拒绝 3-已取消
     */
    private Integer status;
    
    /**
     * 提醒发送状态 0-未发送 1-已发送
     */
    private Integer reminderSent;
    
    /**
     * 签到状态 0-未签到 1-已签到
     */
    private Integer checkInStatus;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    /**
     * 逻辑删除 0-未删除 1-已删除
     */
    @TableLogic
    private Integer deleted;
} 