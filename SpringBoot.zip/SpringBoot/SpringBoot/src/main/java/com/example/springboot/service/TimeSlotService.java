package com.example.springboot.service;

import com.example.springboot.entity.SpaceBooking;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 时间槽服务接口
 * 用于解决循环依赖问题
 */
public interface TimeSlotService {
    
    /**
     * 获取可用时间段
     * @param spaceId 空间ID
     * @param dateTime 日期时间
     * @param bookings 已有预约列表
     * @return 可用时间段列表
     */
    List<Map<String, Object>> getAvailableTimes(Long spaceId, LocalDateTime dateTime, List<SpaceBooking> bookings);
} 