package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Notification;
import com.example.springboot.mapper.NotificationMapper;
import com.example.springboot.mapper.UserMapper;
import com.example.springboot.service.NotificationService;
import com.example.springboot.util.FirebaseMessagingUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 通知服务实现类
 */
@Service
@RequiredArgsConstructor
public class NotificationServiceImpl extends ServiceImpl<NotificationMapper, Notification> implements NotificationService {
    
    private final UserMapper userMapper;
    private final FirebaseMessagingUtil firebaseMessagingUtil;
    
    @Override
    public boolean createNotification(Long userId, Long targetId, Integer type, String title, String content) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setTargetId(targetId);
        notification.setType(type);
        notification.setTitle(title);
        notification.setContent(content);
        notification.setReadStatus(0);
        
        boolean result = save(notification);
        
        // 发送FCM消息
        if (result) {
            String fcmToken = userMapper.selectFcmTokenByUserId(userId);
            if (fcmToken != null && !fcmToken.isEmpty()) {
                firebaseMessagingUtil.sendNotification(fcmToken, title, content, type, targetId);
            }
        }
        
        return result;
    }
    
    @Override
    public boolean createBookingNotification(Long userId, Long bookingId, String title, String content) {
        // 创建预约类型的通知
        return createNotification(userId, bookingId, 2, title, content);
    }
    
    @Override
    public boolean createBookingReminderNotification(Long userId, Long bookingId, String spaceName, LocalDateTime startTime) {
        String timeStr = startTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        String title = "预约即将开始";
        String content = "您在" + spaceName + "的预约将于" + timeStr + "开始，请准时到达。";
        
        return createBookingNotification(userId, bookingId, title, content);
    }
    
    @Override
    public boolean createActivityNotification(Long userId, Long activityId, String title, String content) {
        // 创建活动类型的通知
        return createNotification(userId, activityId, 3, title, content);
    }
    
    @Override
    public boolean createVolunteerNotification(Long userId, Long serviceId, String title, String content) {
        // 创建志愿服务类型的通知
        return createNotification(userId, serviceId, 4, title, content);
    }
    
    @Override
    public Page<Notification> getUserNotifications(int current, int size, Long userId) {
        Page<Notification> page = new Page<>(current, size);
        
        LambdaQueryWrapper<Notification> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Notification::getUserId, userId);
        queryWrapper.orderByDesc(Notification::getCreateTime);
        
        return baseMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public List<Notification> getUnreadNotifications(Long userId) {
        return baseMapper.selectUnreadByUserId(userId);
    }
    
    @Override
    public boolean markAsRead(Long id, Long userId) {
        return baseMapper.markAsRead(id, userId) > 0;
    }
    
    @Override
    public boolean markAllAsRead(Long userId) {
        return baseMapper.markAllAsRead(userId) > 0;
    }
    
    @Override
    public int countUnreadNotifications(Long userId) {
        Integer count = baseMapper.countUnreadByUserId(userId);
        return count != null ? count : 0;
    }
} 