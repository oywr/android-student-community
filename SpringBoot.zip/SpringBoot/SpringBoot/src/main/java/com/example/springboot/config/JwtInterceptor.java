package com.example.springboot.config;

import com.example.springboot.common.Result;
import com.example.springboot.common.ResultCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * JWT拦截器
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtInterceptor implements HandlerInterceptor {

    private final JwtConfig jwtConfig;
    private final ObjectMapper objectMapper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 1. 获取请求头中的token
        String token = request.getHeader("Authorization");

        // 2. 判断token是否存在
        if (!StringUtils.hasText(token)) {
            handleException(response, ResultCode.UNAUTHORIZED, "未登录");
            return false;
        }

        // 3. 解析token
        try {
            token = token.contains("Bearer ") ? token.substring(7) : token;
            log.info("获取到token：{}", token);
            Claims claims = jwtConfig.parseToken(token);
            if (claims == null) {
                handleException(response, ResultCode.UNAUTHORIZED, "未登录");
                return false;
            }

            // 4. 将用户信息存入request
            request.setAttribute("userId", Long.parseLong(claims.get("userId").toString()));
            request.setAttribute("username", claims.get("username"));

            return true;
        } catch (Exception e) {
            log.error("解析token异常", e);
            handleException(response, ResultCode.UNAUTHORIZED, "登录已过期");
            return false;
        }
    }

    /**
     * 处理异常
     */
    private void handleException(HttpServletResponse response, int code, String msg) throws Exception {
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(objectMapper.writeValueAsString(Result.error(code, msg)));
    }
} 