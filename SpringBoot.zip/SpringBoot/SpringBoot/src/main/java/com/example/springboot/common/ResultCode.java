package com.example.springboot.common;

/**
 * 结果状态码常量类
 */
public class ResultCode {
    
    /**
     * 成功
     */
    public static final int SUCCESS = 200;
    
    /**
     * 失败
     */
    public static final int ERROR = 500;
    
    /**
     * 未认证
     */
    public static final int UNAUTHORIZED = 401;
    
    /**
     * 无权限
     */
    public static final int FORBIDDEN = 403;
    
    /**
     * 参数错误
     */
    public static final int PARAM_ERROR = 400;
    
    /**
     * 系统异常
     */
    public static final int SYSTEM_ERROR = 500;
} 