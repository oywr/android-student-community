package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.VolunteerRegistration;
import com.example.springboot.entity.VolunteerService;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.VolunteerRegistrationMapper;
import com.example.springboot.mapper.VolunteerServiceMapper;
import com.example.springboot.service.NotificationService;
import com.example.springboot.service.VolunteerRegistrationService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 志愿服务报名服务实现类
 */
@Service
@RequiredArgsConstructor
public class VolunteerRegistrationServiceImpl extends ServiceImpl<VolunteerRegistrationMapper, VolunteerRegistration> implements VolunteerRegistrationService {
    
    private final VolunteerServiceMapper volunteerServiceMapper;
    private final NotificationService notificationService;
    
    @Override
    @Transactional
    public boolean register(VolunteerRegistration registration) {
        // 查询志愿服务信息
        VolunteerService service = volunteerServiceMapper.selectById(registration.getServiceId());
        if (service == null) {
            throw new ServiceException("志愿服务不存在");
        }
        
        if (service.getStatus() == 2 || service.getStatus() == 3) {
            throw new ServiceException("志愿服务已结束或已取消");
        }
        
        if (service.getCapacity() != null && service.getRegisteredCount() >= service.getCapacity()) {
            throw new ServiceException("志愿服务报名人数已满");
        }
        
        // 检查用户是否有活跃的报名记录（非取消状态）
        LambdaQueryWrapper<VolunteerRegistration> activeQuery = new LambdaQueryWrapper<>();
        activeQuery.eq(VolunteerRegistration::getServiceId, registration.getServiceId());
        activeQuery.eq(VolunteerRegistration::getUserId, registration.getUserId());
        activeQuery.ne(VolunteerRegistration::getStatus, 3); // 非取消状态
        
        Long activeCount = baseMapper.selectCount(activeQuery);
        if (activeCount > 0) {
            throw new ServiceException("您已经报名该志愿服务");
        }
        
        boolean result = false;
        
        // 检查是否存在已取消的报名记录
        LambdaQueryWrapper<VolunteerRegistration> canceledQuery = new LambdaQueryWrapper<>();
        canceledQuery.eq(VolunteerRegistration::getServiceId, registration.getServiceId());
        canceledQuery.eq(VolunteerRegistration::getUserId, registration.getUserId());
        canceledQuery.eq(VolunteerRegistration::getStatus, 3); // 已取消状态
        
        VolunteerRegistration canceledRegistration = getOne(canceledQuery);
        
        if (canceledRegistration != null) {
            // 如果存在已取消的报名记录，则更新该记录
            canceledRegistration.setRegistrationTime(LocalDateTime.now());
            canceledRegistration.setStatus(1); // 设置为已通过
            canceledRegistration.setReminderSent(0);
            canceledRegistration.setCheckInStatus(0);
            canceledRegistration.setActualHours(0.0f);
            result = updateById(canceledRegistration);
            
            // 更新registration对象的ID，以便后续使用
            registration.setId(canceledRegistration.getId());
        } else {
            // 创建新的报名记录
            registration.setRegistrationTime(LocalDateTime.now());
            registration.setStatus(1); // 设置为已通过
            registration.setReminderSent(0);
            registration.setCheckInStatus(0);
            registration.setActualHours(0.0f);
            result = save(registration);
        }
        
        // 更新志愿服务报名人数
        if (result) {
            service.setRegisteredCount(service.getRegisteredCount() + 1);
            volunteerServiceMapper.updateById(service);
            
            // 创建通知
            notificationService.createVolunteerNotification(
                registration.getUserId(),
                service.getId(),
                "志愿服务报名成功",
                "您已成功报名" + service.getTitle() + "志愿服务，请准时参加。"
            );
        }
        
        return result;
    }
    
    @Override
    @Transactional
    public boolean cancelRegistration(Long id, Long userId) {
        // 查询报名信息
        LambdaQueryWrapper<VolunteerRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(VolunteerRegistration::getServiceId, id);
        queryWrapper.eq(VolunteerRegistration::getUserId, userId);
        
        VolunteerRegistration registration = getOne(queryWrapper);
        if (registration == null) {
            throw new ServiceException("报名记录不存在");
        }
        
        if (registration.getStatus() == 3) {
            throw new ServiceException("已取消报名");
        }
        
        // 查询志愿服务信息
        VolunteerService service = volunteerServiceMapper.selectById(registration.getServiceId());
        if (service == null) {
            throw new ServiceException("志愿服务不存在");
        }
        
        if (service.getStatus() == 2) {
            throw new ServiceException("志愿服务已结束，无法取消报名");
        }
        
        // 设置状态为已取消
        registration.setStatus(3);
        
        boolean result = updateById(registration);
        // 更新志愿服务报名人数
        if (result) {
            service.setRegisteredCount(service.getRegisteredCount() - 1);
            volunteerServiceMapper.updateById(service);
            
            // 创建通知
            notificationService.createVolunteerNotification(
                userId,
                service.getId(),
                "取消志愿服务报名",
                "您已取消" + service.getTitle() + "志愿服务的报名。"
            );
        }
        
        return result;
    }
    
    @Override
    public boolean checkIn(Long id, Long userId) {
        // 查询报名信息
        LambdaQueryWrapper<VolunteerRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(VolunteerRegistration::getServiceId, id);
        queryWrapper.eq(VolunteerRegistration::getUserId, userId);
        
        VolunteerRegistration registration = getOne(queryWrapper);
        if (registration == null) {
            throw new ServiceException("报名记录不存在");
        }
        
        if (registration.getStatus() != 1) {
            throw new ServiceException("报名未通过，无法签到");
        }
        
        if (registration.getCheckInStatus() == 1) {
            throw new ServiceException("已签到");
        }
        
        // 设置为已签到
        registration.setCheckInStatus(1);
        
        boolean result = updateById(registration);
        
        // 创建通知
        if (result) {
            VolunteerService service = volunteerServiceMapper.selectById(registration.getServiceId());
            notificationService.createVolunteerNotification(
                userId,
                service.getId(),
                "签到成功",
                "您已成功签到" + service.getTitle() + "志愿服务。"
            );
        }
        
        return result;
    }
    
    @Override
    @Transactional
    public boolean recordHours(Long id, Float hours) {
        // 查询报名信息
        VolunteerRegistration registration = getById(id);
        if (registration == null) {
            throw new ServiceException("报名记录不存在");
        }
        
        if (registration.getStatus() != 1) {
            throw new ServiceException("报名未通过，无法记录工时");
        }
        
        if (hours < 0) {
            throw new ServiceException("工时不能为负数");
        }
        
        // 查询志愿服务信息，检查最大工时
        VolunteerService service = volunteerServiceMapper.selectById(registration.getServiceId());
        if (service != null && service.getHours() != null && hours > service.getHours()) {
            throw new ServiceException("工时不能超过志愿服务规定的最大工时：" + service.getHours());
        }
        
        // 记录工时
        VolunteerRegistration updateRegistration = new VolunteerRegistration();
        updateRegistration.setId(id);
        updateRegistration.setActualHours(hours);
        
        boolean result = updateById(updateRegistration);
        
        // 创建通知
        if (result) {
            notificationService.createVolunteerNotification(
                registration.getUserId(),
                service.getId(),
                "志愿工时已记录",
                "您在" + service.getTitle() + "志愿服务中获得了" + hours + "小时的志愿工时。"
            );
        }
        
        return result;
    }
    
    @Override
    public Page<VolunteerRegistration> getUserRegistrations(int current, int size, Long userId) {
        Page<VolunteerRegistration> page = new Page<>(current, size);
        
        LambdaQueryWrapper<VolunteerRegistration> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(VolunteerRegistration::getUserId, userId);
        queryWrapper.orderByDesc(VolunteerRegistration::getRegistrationTime);
        
        return baseMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public List<VolunteerRegistration> getByServiceId(Long serviceId) {
        return baseMapper.selectByServiceId(serviceId);
    }
    
    @Override
    public Float countUserHours(Long userId) {
        Float hours = baseMapper.countHoursByUserId(userId);
        return hours != null ? hours : 0.0f;
    }
    
    @Override
    @Scheduled(fixedRate = 60000) // 每分钟执行一次
    public void handleVolunteerReminders() {
        LocalDateTime now = LocalDateTime.now();
        
        // 查询所有即将开始的志愿服务（1小时内）
        LambdaQueryWrapper<VolunteerService> serviceQuery = new LambdaQueryWrapper<>();
        serviceQuery.eq(VolunteerService::getStatus, 0); // 未开始的服务
        serviceQuery.le(VolunteerService::getStartTime, now.plusHours(1));
        serviceQuery.gt(VolunteerService::getStartTime, now);
        
        List<VolunteerService> upcomingServices = volunteerServiceMapper.selectList(serviceQuery);
        
        for (VolunteerService service : upcomingServices) {
            // 查询该志愿服务的所有已通过报名且未发送提醒的记录
            LambdaQueryWrapper<VolunteerRegistration> registrationQuery = new LambdaQueryWrapper<>();
            registrationQuery.eq(VolunteerRegistration::getServiceId, service.getId());
            registrationQuery.eq(VolunteerRegistration::getStatus, 1);
            registrationQuery.eq(VolunteerRegistration::getReminderSent, 0);
            
            List<VolunteerRegistration> registrations = baseMapper.selectList(registrationQuery);
            
            for (VolunteerRegistration registration : registrations) {
                // 发送提醒通知
                notificationService.createVolunteerNotification(
                    registration.getUserId(),
                    service.getId(),
                    "志愿服务即将开始",
                    "您报名的" + service.getTitle() + "志愿服务将于" + service.getStartTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) + "开始，请准时参加。"
                );
                
                // 标记提醒已发送
                VolunteerRegistration updateRegistration = new VolunteerRegistration();
                updateRegistration.setId(registration.getId());
                updateRegistration.setReminderSent(1);
                updateById(updateRegistration);
            }
        }
    }
} 