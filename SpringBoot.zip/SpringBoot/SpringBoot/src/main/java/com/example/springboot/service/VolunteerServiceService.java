package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.VolunteerService;

import java.util.List;

/**
 * 志愿服务服务接口
 */
public interface VolunteerServiceService extends IService<VolunteerService> {
    
    /**
     * 分页查询志愿服务列表
     * @param current 当前页
     * @param size 每页大小
     * @return 分页结果
     */
    Page<VolunteerService> listServices(int current, int size);
    
    /**
     * 查询最新的志愿服务列表
     * @param limit 限制数量
     * @return 志愿服务列表
     */
    List<VolunteerService> getLatestServices(int limit);
} 