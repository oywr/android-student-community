package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Notification;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 通知服务接口
 */
public interface NotificationService extends IService<Notification> {
    
    /**
     * 创建通知
     * @param userId 用户ID
     * @param targetId 目标ID
     * @param type 通知类型
     * @param title 通知标题
     * @param content 通知内容
     * @return 创建结果
     */
    boolean createNotification(Long userId, Long targetId, Integer type, String title, String content);
    
    /**
     * 创建预约通知
     * @param userId 用户ID
     * @param bookingId 预约ID
     * @param title 通知标题
     * @param content 通知内容
     * @return 创建结果
     */
    boolean createBookingNotification(Long userId, Long bookingId, String title, String content);
    
    /**
     * 创建预约提醒通知
     * @param userId 用户ID
     * @param bookingId 预约ID
     * @param spaceName 空间名称
     * @param startTime 开始时间
     * @return 创建结果
     */
    boolean createBookingReminderNotification(Long userId, Long bookingId, String spaceName, LocalDateTime startTime);
    
    /**
     * 创建活动通知
     * @param userId 用户ID
     * @param activityId 活动ID
     * @param title 通知标题
     * @param content 通知内容
     * @return 创建结果
     */
    boolean createActivityNotification(Long userId, Long activityId, String title, String content);
    
    /**
     * 创建志愿服务通知
     * @param userId 用户ID
     * @param serviceId 服务ID
     * @param title 通知标题
     * @param content 通知内容
     * @return 创建结果
     */
    boolean createVolunteerNotification(Long userId, Long serviceId, String title, String content);
    
    /**
     * 分页查询用户通知列表
     * @param current 当前页
     * @param size 每页大小
     * @param userId 用户ID
     * @return 分页结果
     */
    Page<Notification> getUserNotifications(int current, int size, Long userId);
    
    /**
     * 查询用户未读通知列表
     * @param userId 用户ID
     * @return 通知列表
     */
    List<Notification> getUnreadNotifications(Long userId);
    
    /**
     * 标记通知为已读
     * @param id 通知ID
     * @param userId 用户ID
     * @return 标记结果
     */
    boolean markAsRead(Long id, Long userId);
    
    /**
     * 标记所有通知为已读
     * @param userId 用户ID
     * @return 标记结果
     */
    boolean markAllAsRead(Long userId);
    
    /**
     * 统计用户未读通知数量
     * @param userId 用户ID
     * @return 未读通知数量
     */
    int countUnreadNotifications(Long userId);
} 