package com.example.springboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.Activity;
import com.example.springboot.entity.ActivityRating;
import com.example.springboot.entity.ActivityRegistration;
import com.example.springboot.service.ActivityRatingService;
import com.example.springboot.service.ActivityRegistrationService;
import com.example.springboot.service.ActivityService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 活动控制器
 */
@RestController
@RequestMapping("/api/activity")
@RequiredArgsConstructor
public class ActivityController {
    
    private final ActivityService activityService;
    private final ActivityRegistrationService activityRegistrationService;
    private final ActivityRatingService activityRatingService;
    
    /**
     * 获取活动列表
     */
    @GetMapping("/list")
    public Result<Page<Activity>> listActivities(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer type) {
        
        Page<Activity> page = activityService.listActivities(current, size, type);
        return Result.success(page);
    }
    
    /**
     * 获取活动详情
     */
    @GetMapping("/{id}")
    public Result<Map<String, Object>> getActivityById(
            @PathVariable Long id,
            @RequestAttribute(value = "userId", required = false) Long userId) {
        Activity activity = activityService.getById(id);
        
        if (activity == null) {
            return Result.error("活动不存在");
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("id", activity.getId());
        result.put("title", activity.getTitle());
        result.put("description", activity.getDescription());
        result.put("imageUrl", activity.getImageUrl());
        result.put("startTime", activity.getStartTime());
        result.put("endTime", activity.getEndTime());
        result.put("location", activity.getLocation());
        result.put("capacity", activity.getCapacity());
        result.put("registeredCount", activity.getRegisteredCount());
        result.put("type", activity.getType());
        result.put("status", activity.getStatus());
        result.put("averageRating", activity.getAverageRating());
        
        // 查询用户是否已报名和签到状态
        boolean isRegistered = false;
        boolean isCheckedIn = false;
        if (userId != null) {
            LambdaQueryWrapper<ActivityRegistration> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(ActivityRegistration::getActivityId, id);
            queryWrapper.eq(ActivityRegistration::getUserId, userId);
            queryWrapper.in(ActivityRegistration::getStatus, 0, 1); // 待审核或已通过
            
            ActivityRegistration registration = activityRegistrationService.getOne(queryWrapper);
            if (registration != null) {
                isRegistered = true;
                isCheckedIn = registration.getCheckInStatus() == 1;
            }
        }
        result.put("isRegistered", isRegistered);
        result.put("isCheckedIn", isCheckedIn);
        
        return Result.success(result);
    }
    
    /**
     * 搜索活动
     */
    @GetMapping("/search")
    public Result<Page<Activity>> searchActivities(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer type) {
        
        Page<Activity> page = activityService.searchActivities(current, size, keyword, type);
        return Result.success(page);
    }
    
    /**
     * 报名活动
     */
    @PostMapping("/register")
    public Result<Map<String, Object>> registerActivity(
            @RequestBody Map<String, Long> registerMap,
            @RequestAttribute("userId") Long userId) {
        
        Long activityId = registerMap.get("activityId");
        if (activityId == null) {
            return Result.error("活动ID不能为空");
        }
        
        // 创建报名记录
        ActivityRegistration registration = new ActivityRegistration();
        registration.setActivityId(activityId);
        registration.setUserId(userId);
        
        boolean result = activityRegistrationService.register(registration);
        
        if (result) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", registration.getId());
            return Result.success("报名成功", data);
        } else {
            return Result.error("报名失败");
        }
    }
    
    /**
     * 获取活动报名列表
     */
    @GetMapping("/registrations")
    public Result<Map<String, Object>> getRegistrations(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestAttribute("userId") Long userId) {
        
        // 获取用户报名记录
        Page<ActivityRegistration> page = activityRegistrationService.getUserRegistrations(current, size, userId);
        
        // 获取活动IDs
        List<Long> activityIds = page.getRecords().stream()
                .map(ActivityRegistration::getActivityId)
                .collect(Collectors.toList());
        
        // 查询活动信息
        Map<Long, Activity> activityMap = new HashMap<>();
        if (!activityIds.isEmpty()) {
            List<Activity> activities = activityService.listByIds(activityIds);
            activityMap = activities.stream()
                    .collect(Collectors.toMap(Activity::getId, activity -> activity));
        }
        
        // 组装结果
        List<Map<String, Object>> recordsWithActivity = new ArrayList<>();
        for (ActivityRegistration registration : page.getRecords()) {
            Map<String, Object> record = new HashMap<>();
            // 添加报名信息
            record.put("id", registration.getId());
            record.put("activityId", registration.getActivityId());
            record.put("userId", registration.getUserId());
            record.put("registrationTime", registration.getRegistrationTime());
            record.put("status", registration.getStatus());
            record.put("reminderSent", registration.getReminderSent());
            record.put("checkInStatus", registration.getCheckInStatus());
            record.put("remark", registration.getRemark());
            record.put("createTime", registration.getCreateTime());
            
            // 添加签到状态的布尔值，方便前端直接使用
            record.put("isCheckedIn", registration.getCheckInStatus() == 1);
            
            // 添加活动信息
            Activity activity = activityMap.get(registration.getActivityId());
            if (activity != null) {
                Map<String, Object> activityInfo = new HashMap<>();
                activityInfo.put("id", activity.getId());
                activityInfo.put("title", activity.getTitle());
                activityInfo.put("description", activity.getDescription());
                activityInfo.put("imageUrl", activity.getImageUrl());
                activityInfo.put("startTime", activity.getStartTime());
                activityInfo.put("endTime", activity.getEndTime());
                activityInfo.put("location", activity.getLocation());
                activityInfo.put("status", activity.getStatus());
                activityInfo.put("type", activity.getType());
                record.put("activity", activityInfo);
            }
            
            recordsWithActivity.add(record);
        }
        
        // 构建分页结果
        Map<String, Object> result = new HashMap<>();
        result.put("records", recordsWithActivity);
        result.put("total", page.getTotal());
        result.put("size", page.getSize());
        result.put("current", page.getCurrent());
        
        return Result.success(result);
    }
    
    /**
     * 取消活动报名
     */
    @PutMapping("/registration/{id}/cancel")
    public Result<Void> cancelRegistration(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = activityRegistrationService.cancelRegistration(id, userId);
        
        return result ? Result.success("取消成功", null) : Result.error("取消失败");
    }
    
    /**
     * 活动签到
     */
    @PutMapping("/registration/{id}/check-in")
    public Result<Void> checkIn(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = activityRegistrationService.checkIn(id, userId);
        
        return result ? Result.success("签到成功", null) : Result.error("签到失败");
    }
    
    /**
     * 评价活动
     */
    @PostMapping("/rating")
    public Result<Void> rateActivity(
            @RequestBody ActivityRating rating,
            @RequestAttribute("userId") Long userId) {
        
        // 设置用户ID
        rating.setUserId(userId);
        
        boolean result = activityRatingService.rateActivity(rating);
        
        return result ? Result.success("评价成功", null) : Result.error("评价失败");
    }
    
    /**
     * 获取活动评价列表
     */
    @GetMapping("/{id}/ratings")
    public Result<Page<ActivityRating>> getActivityRatings(
            @PathVariable Long id,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size) {
        
        Page<ActivityRating> page = activityRatingService.getActivityRatings(current.intValue(), size.intValue(), id);
        return Result.success(page);
    }
} 