package com.example.springboot.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.Feedback;
import com.example.springboot.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 反馈控制器
 */
@RestController
@RequestMapping("/api/feedback")
@RequiredArgsConstructor
public class FeedbackController {
    
    private final FeedbackService feedbackService;
    
    /**
     * 提交反馈
     */
    @PostMapping
    public Result<Map<String, Object>> submitFeedback(
            @RequestBody Feedback feedback,
            @RequestAttribute("userId") Long userId) {
        
        // 设置用户ID
        feedback.setUserId(userId);
        
        boolean result = feedbackService.submit(feedback);
        
        if (result) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", feedback.getId());
            return Result.success("提交成功", data);
        } else {
            return Result.error("提交失败");
        }
    }
    
    /**
     * 获取用户反馈列表
     */
    @GetMapping
    public Result<Page<Feedback>> getUserFeedbacks(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestAttribute("userId") Long userId) {
        
        Page<Feedback> page = feedbackService.getUserFeedbacks(current, size, userId);
        return Result.success(page);
    }
} 