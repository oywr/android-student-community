package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.CommunityPost;
import com.example.springboot.entity.PostComment;
import com.example.springboot.mapper.PostCommentMapper;
import com.example.springboot.service.CommunityPostService;
import com.example.springboot.service.PostCommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 帖子评论服务实现类
 */
@Service
@RequiredArgsConstructor
public class PostCommentServiceImpl extends ServiceImpl<PostCommentMapper, PostComment> implements PostCommentService {
    
    private final CommunityPostService communityPostService;
    
    @Override
    @Transactional
    public boolean createComment(PostComment comment) {
        // 设置初始状态为待审核
        comment.setStatus(0);
        
        // 初始化点赞数
        comment.setLikes(0);
        
        // 如果没有设置父评论ID，默认为0（一级评论）
        if (comment.getParentId() == null) {
            comment.setParentId(0L);
        }
        
        boolean saved = save(comment);
        
        if (saved) {
            // 更新帖子评论数
            CommunityPost post = communityPostService.getById(comment.getPostId());
            if (post != null) {
                post.setComments(post.getComments() + 1);
                communityPostService.updateById(post);
            }
        }
        
        return saved;
    }
    
    @Override
    public Page<PostComment> listComments(Long postId, Integer current, Integer size) {
        Page<PostComment> page = new Page<>(current, size);
        LambdaQueryWrapper<PostComment> queryWrapper = new LambdaQueryWrapper<>();
        
        // 查询条件：帖子ID
        queryWrapper.eq(PostComment::getPostId, postId);
        
        // 只查询已发布的评论
        queryWrapper.eq(PostComment::getStatus, 1);
        
        // 先查询一级评论
        queryWrapper.eq(PostComment::getParentId, 0);
        
        // 按创建时间升序排序
        queryWrapper.orderByAsc(PostComment::getCreateTime);
        
        return page(page, queryWrapper);
    }
} 