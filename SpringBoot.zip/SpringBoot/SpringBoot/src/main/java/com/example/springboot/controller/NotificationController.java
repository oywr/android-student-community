package com.example.springboot.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.common.Result;
import com.example.springboot.entity.Notification;
import com.example.springboot.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 通知控制器
 */
@RestController
@RequestMapping("/api/notification")
@RequiredArgsConstructor
public class NotificationController {
    
    private final NotificationService notificationService;
    
    /**
     * 获取通知列表
     */
    @GetMapping("/list")
    public Result<Page<Notification>> getNotifications(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestAttribute("userId") Long userId) {
        
        Page<Notification> page = notificationService.getUserNotifications(current, size, userId);
        return Result.success(page);
    }
    
    /**
     * 获取未读通知数量
     */
    @GetMapping("/unread/count")
    public Result<Map<String, Object>> getUnreadCount(
            @RequestAttribute("userId") Long userId) {
        
        int count = notificationService.countUnreadNotifications(userId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("count", count);
        
        return Result.success(result);
    }
    
    /**
     * 标记通知为已读
     */
    @PutMapping("/{id}/read")
    public Result<Void> markAsRead(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId) {
        
        boolean result = notificationService.markAsRead(id, userId);
        
        return result ? Result.success("标记成功", null) : Result.error("标记失败");
    }
    
    /**
     * 标记所有通知为已读
     */
    @PutMapping("/read/all")
    public Result<Void> markAllAsRead(
            @RequestAttribute("userId") Long userId) {
        
        boolean result = notificationService.markAllAsRead(userId);
        
        return result ? Result.success("标记成功", null) : Result.error("标记失败");
    }
} 