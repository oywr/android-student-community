package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.CommunityPost;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 社区帖子Mapper接口
 */
public interface CommunityPostMapper extends BaseMapper<CommunityPost> {
    
    /**
     * 查询最新的社区帖子
     * @param limit 限制数量
     * @return 帖子列表
     */
    @Select("SELECT * FROM community_post WHERE status = 1 AND deleted = 0 ORDER BY create_time DESC LIMIT #{limit}")
    List<CommunityPost> selectLatestPosts(Integer limit);
    
    /**
     * 查询用户发布的所有帖子
     * @param userId 用户ID
     * @return 帖子列表
     */
    @Select("SELECT * FROM community_post WHERE user_id = #{userId} AND deleted = 0 ORDER BY create_time DESC")
    List<CommunityPost> selectByUserId(Long userId);
} 