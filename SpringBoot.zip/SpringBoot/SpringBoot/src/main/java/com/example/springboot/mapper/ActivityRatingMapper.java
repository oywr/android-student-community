package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.ActivityRating;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 活动评价Mapper接口
 */
public interface ActivityRatingMapper extends BaseMapper<ActivityRating> {
    
    /**
     * 查询活动的所有评价
     * @param activityId 活动ID
     * @return 评价列表
     */
    @Select("SELECT * FROM activity_rating WHERE activity_id = #{activityId} AND deleted = 0 ORDER BY create_time DESC")
    List<ActivityRating> selectByActivityId(Long activityId);
    
    /**
     * 计算活动的平均评分
     * @param activityId 活动ID
     * @return 平均评分
     */
    @Select("SELECT AVG(rating) FROM activity_rating WHERE activity_id = #{activityId} AND deleted = 0")
    Float calculateAverageRating(Long activityId);
} 