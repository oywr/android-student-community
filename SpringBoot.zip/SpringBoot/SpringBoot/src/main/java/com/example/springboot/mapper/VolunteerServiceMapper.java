package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.VolunteerService;

/**
 * 志愿服务Mapper接口
 */
public interface VolunteerServiceMapper extends BaseMapper<VolunteerService> {
    
} 