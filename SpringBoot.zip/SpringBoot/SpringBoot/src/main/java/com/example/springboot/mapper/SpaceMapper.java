package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Space;

/**
 * 空间Mapper接口
 */
public interface SpaceMapper extends BaseMapper<Space> {
    
} 