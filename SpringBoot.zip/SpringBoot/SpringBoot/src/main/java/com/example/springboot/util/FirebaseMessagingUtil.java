package com.example.springboot.util;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Firebase消息推送工具类
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FirebaseMessagingUtil {
    
    private final FirebaseMessaging firebaseMessaging;
    
    /**
     * 发送通知
     * @param token 设备令牌
     * @param title 通知标题
     * @param body 通知内容
     * @param type 通知类型
     * @param targetId 目标ID
     */
    public void sendNotification(String token, String title, String body, int type, Long targetId) {
        if (firebaseMessaging == null) {
            log.warn("FirebaseMessaging is not available. Notification not sent: title={}, body={}", title, body);
            return;
        }
        
        try {
            // 构建通知
            Notification notification = Notification.builder()
                    .setTitle(title)
                    .setBody(body)
                    .build();
            
            // 构建消息
            Message message = Message.builder()
                    .setToken(token)
                    .setNotification(notification)
                    .putData("type", String.valueOf(type))
                    .putData("targetId", String.valueOf(targetId))
                    .build();
            
            // 发送消息
            String response = firebaseMessaging.send(message);
            log.info("Successfully sent message: {}", response);
        } catch (Exception e) {
            log.error("Failed to send Firebase notification", e);
        }
    }
} 