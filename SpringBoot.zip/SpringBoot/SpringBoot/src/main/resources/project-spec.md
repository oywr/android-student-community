# Spring Boot 项目规范

## 项目概述
本项目是一个基于Spring Boot 3.1的后端服务项目，采用JWT认证机制，使用MyBatis-Plus作为ORM框架，基于MySQL数据库，并集成Firebase Cloud Messaging实现消息推送功能。

## 技术栈
- Java 17
- Spring Boot 3.1.0
- MyBatis-Plus 3.5.3
- JWT 0.11.5
- MySQL 8.0+
- Maven
- Firebase Admin SDK 9.2.0

## 项目结构
```
src/main/java/com/example/springboot/
├── Application.java                  // 应用程序入口
├── common/                           // 通用类
│   ├── PageResult.java               // 分页结果封装
│   ├── R.java                        // 统一返回结果封装
│   └── ResultCode.java               // 结果状态码常量
├── config/                           // 配置类
│   ├── JwtConfig.java                // JWT配置
│   ├── JwtInterceptor.java           // JWT拦截器
│   ├── FirebaseConfig.java           // Firebase配置
│   └── WebMvcConfig.java             // Web配置
├── controller/                       // 控制器
│   ├── AuthController.java           // 认证控制器
│   ├── UserController.java           // 用户控制器
│   └── NotificationController.java   // 通知控制器
├── entity/                           // 实体类
│   ├── User.java                     // 用户实体
│   └── Notification.java             // 通知实体
├── exception/                        // 异常处理
│   ├── GlobalExceptionHandler.java   // 全局异常处理器
│   └── ServiceException.java         // 业务异常
├── mapper/                           // 数据访问层
│   ├── UserMapper.java               // 用户Mapper
│   └── NotificationMapper.java       // 通知Mapper
├── service/                          // 服务层
│   ├── UserService.java              // 用户服务接口
│   ├── NotificationService.java      // 通知服务接口
│   └── impl/
│       ├── UserServiceImpl.java      // 用户服务实现
│       └── NotificationServiceImpl.java // 通知服务实现
└── util/                             // 工具类
    └── FirebaseMessagingUtil.java    // Firebase消息工具类

src/main/resources/
├── application.properties            // 应用配置文件
├── firebase-service-account.json     // Firebase服务账号密钥
├── db/migration/                     // Flyway数据库迁移
│   ├── V1__Create_User_Table.sql     // 初始用户表创建脚本
│   └── V2__Create_Notification_Table.sql // 通知表创建脚本
└── mapper/                           // MyBatis XML映射文件
    ├── UserMapper.xml                // 用户Mapper XML
    └── NotificationMapper.xml        // 通知Mapper XML
```

## 分层架构
- **Controller层**：负责接收请求、参数校验和返回结果
- **Service层**：负责业务逻辑处理
- **Mapper层**：负责数据库访问
- **Entity层**：实体类，映射数据库表结构
- **Common层**：通用工具类和常量
- **Config层**：配置类
- **Exception层**：异常处理
- **Util层**：工具类，如Firebase消息推送工具

## API设计规范
- RESTful API设计风格
- 统一使用`R<T>`作为返回结果封装类
- 成功返回：`R.success(data, message)`，状态码为200
- 失败返回：`R.error(code, message)`，状态码由具体业务定义
- 使用`@RestController`注解声明控制器
- URL命名采用kebab-case，例如：`/api/user-info`

## 异常处理
- 使用`@RestControllerAdvice`全局异常处理
- 业务异常使用`ServiceException`
- 参数校验异常使用`MethodArgumentNotValidException`
- 所有异常都统一返回`R`对象

## JWT认证
- 使用`jjwt`库实现JWT生成和解析
- Token通过请求头`Authorization`传递
- 登录接口：`/api/auth/login`，返回token
- 注册接口：`/api/auth/register`
- 通过`JwtInterceptor`实现接口拦截和认证
- 通过`WebMvcConfig`配置拦截器和跨域

## Firebase Cloud Messaging
- 使用Firebase Admin SDK实现服务端消息推送
- 配置文件中设置Firebase项目ID和凭据路径
- 客户端FCM令牌通过API接口上传到服务端
- 消息类型分为：预约提醒、活动提醒、志愿服务提醒等
- 消息分为数据消息和通知消息两种类型
- 实现消息推送工具类，简化消息发送流程

## 数据库
- 使用MySQL 8.0以上版本
- 使用Flyway进行数据库版本管理
- 使用MyBatis-Plus简化SQL操作
- 使用逻辑删除，不物理删除数据
- 表名、字段名采用蛇形命名法，例如：`create_time`
- 实体类采用驼峰命名法，例如：`createTime`
- 用户表添加`fcm_token`字段，存储Firebase消息令牌
- 通知表记录所有系统通知，包括推送状态

## 安全规范
- 密码使用MD5加密存储（生产环境建议使用更安全的算法）
- JWT密钥通过配置文件配置，确保足够长度和复杂度
- 使用SecretKey进行JWT签名
- 敏感操作需要验证用户身份
- Firebase服务账号密钥文件安全存储，不上传到代码仓库
- 推送消息不包含敏感数据，敏感信息通过API接口获取

## 编码规范
- 使用Lombok简化代码
- 包名全部小写
- 类名采用CamelCase命名法，例如：`UserController`
- 方法名采用小驼峰命名法，例如：`getUserInfo`
- 常量全部大写，单词之间下划线分隔，例如：`MAX_COUNT`
- 变量名采用小驼峰命名法，例如：`userName`

## 其他规范
- 代码中需要添加足够的注释
- 配置使用配置文件外部化，避免硬编码
- 使用构造器注入依赖，避免字段注入
- 消息推送遵循最小化原则，只发送必要的信息
- 客户端应实现消息接收失败的本地提醒机制
- 预约提醒应在预约开始前至少1小时发送 