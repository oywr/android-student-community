# 华南师范大学滨海校园预约服务应用需求分析

## 项目概述

华南师范大学滨海校园预约服务应用旨在通过数字化手段优化校园公共资源管理，提升学生社区服务效率，构建智慧化"一站式"学生社区平台。该应用围绕公共空间预约、学生活动报名、志愿服务管理三大核心场景展开，结合校园实际需求设计功能模块，通过移动端技术实现资源的高效分配与信息整合。

## 技术架构选型

### 前端技术栈
- Android Studio作为主要开发工具
- Android Jetpack组件库构建响应式界面
- Navigation组件管理页面跳转逻辑
- ViewModel与LiveData实现数据驱动UI更新
- Handler处理异步通信
- JSON解析网络数据
- Firebase Cloud Messaging实现消息推送
- AlarmManager与BroadcastReceiver实现本地提醒

### 后端技术栈
- Java 17
- Spring Boot 3.1.0（使用内嵌服务器）
- MyBatis-Plus 3.5.3
- JWT 0.11.5
- MySQL 8.0+
- Maven构建工具
- Firebase Admin SDK进行服务端消息推送

## 应用模块与功能设计

### 1. 用户认证模块

#### 1.1 登录功能
- 支持学号登录
- 支持手机号登录
- JWT令牌认证机制

#### 1.2 注册功能
- 学号/手机号注册
- 密码设置
- 基本信息填写

#### 1.3 找回密码功能
- 手机号验证找回

### 2. 公共空间预约模块

#### 2.1 公共空间信息
- 45间功能房信息展示
- 场所详情查看（介绍、容量、位置、图片等）

#### 2.2 一键预约
- 日历式时间选择
- 可预约时段实时显示
- 在线提交预约申请

#### 2.3 预约提醒
- 预约成功通知
- 预约时间临近提醒（通过FCM和本地闹钟实现）
- 预约状态变更通知

#### 2.4 历史预约记录
- 历史预约记录查询
- 取消预约功能
- 修改预约时间功能

### 3. 学生活动报名模块

#### 3.1 活动推送
- 首页活动信息流
- 活动详情页（海报、介绍、条件、名额）

#### 3.2 一键报名
- 在线快速报名
- 报名状态查询
- 取消报名功能

#### 3.3 活动搜索
- 关键词搜索
- 活动编码检索

#### 3.4 活动分类
- 按活动类型分类
- 按时间排序
- 按热度排序

#### 3.5 活动评价
- 活动评分功能
- 评价留言功能
- 查看他人评价

### 4. 志愿服务报名模块

#### 4.1 服务信息
- 项目列表展示
- 项目详情查看

#### 4.2 一键报名
- 在线报名申请
- 签到功能

#### 4.3 社区交流
- 服务心得分享
- 评论互动功能

### 5. 个人中心模块

#### 5.1 个人信息
- 基本信息展示
- 信息修改功能

#### 5.2 修改密码
- 修改登录密码
- 密码安全验证

#### 5.3 意见反馈
- 问题反馈
- 功能建议

#### 5.4 切换账户
- 客户端清除登录信息（纯客户端功能）
- 返回登录页面重新登录

### 6. 通知系统模块

#### 6.1 远程推送通知
- 基于Firebase Cloud Messaging实现
- 预约状态变更通知
- 活动即将开始提醒
- 志愿服务即将开始提醒

#### 6.2 本地提醒
- 基于AlarmManager与BroadcastReceiver实现
- 预约时间临近提醒
- 应用内消息提示

#### 6.3 通知持久化
- 设备重启后保持提醒状态
- 历史通知查看

## 数据库设计

### 主要数据表

1. **用户表(user)**
   - 存储用户基本信息
   - 字段：id, username, password, real_name, phone, email, avatar, status, fcm_token 等

2. **空间表(space)**
   - 存储校园内各功能房间信息
   - 字段：id, name, description, location, capacity, image_url, status 等

3. **空间预约表(space_booking)**
   - 记录空间预约信息
   - 字段：id, space_id, user_id, start_time, end_time, status, reminder_time, reminder_sent 等

4. **活动表(activity)**
   - 存储学生活动信息
   - 字段：id, title, description, image_url, start_time, end_time, location, capacity, type, status, average_rating 等

5. **活动报名表(activity_registration)**
   - 记录活动报名信息
   - 字段：id, activity_id, user_id, registration_time, status, reminder_sent 等

6. **活动评价表(activity_rating)**
   - 记录活动评价信息
   - 字段：id, activity_id, user_id, rating, comment, create_time 等

7. **志愿服务表(volunteer_service)**
   - 存储志愿服务项目信息
   - 字段：id, title, description, image_url, start_time, end_time, location, capacity, hours, status 等

8. **志愿服务报名表(volunteer_registration)**
   - 记录志愿服务报名信息
   - 字段：id, service_id, user_id, registration_time, status, actual_hours, reminder_sent 等

9. **反馈表(feedback)**
   - 存储用户反馈信息
   - 字段：id, user_id, content, type, status, reply 等

10. **社区帖子表(community_post)**
    - 存储志愿服务交流社区帖子
    - 字段：id, user_id, title, content, image_url, type, likes, comments 等

11. **帖子评论表(post_comment)**
    - 存储社区帖子评论
    - 字段：id, post_id, user_id, content, likes 等

12. **通知表(notification)**
    - 存储系统通知信息
    - 字段：id, user_id, title, content, type, target_id, read_status, create_time 等 