# 华南师范大学滨海校园预约服务应用实现指南

## 开发环境配置

### Android端开发环境
- Android Studio最新版
- JDK 11或更高版本
- Android SDK API 30 (Android 11)或更高
- Gradle 7.0+
- Firebase项目配置

### 后端开发环境
- IntelliJ IDEA / Eclipse
- JDK 17
- Maven 3.8+
- MySQL 8.0+
- Spring Boot内嵌服务器

## Android端实现方案

### 整体架构
采用简化版的MVVM架构：
- **Model**: 数据模型和仓库
- **View**: Activity和Fragment
- **ViewModel**: 负责UI状态管理和业务逻辑

### 项目结构
```
app/
├── src/main/
│   ├── java/com/example/studentcommunity/
│   │   ├── activity/             # 所有Activity
│   │   ├── adapter/              # RecyclerView适配器
│   │   ├── fragment/             # 所有Fragment
│   │   ├── model/                # 数据模型类
│   │   ├── network/              # 网络请求相关
│   │   ├── util/                 # 工具类
│   │   ├── viewmodel/            # ViewModel类
│   │   └── MainActivity.java     # 主Activity
│   ├── res/                      # 资源文件
│   └── AndroidManifest.xml       # 应用配置
└── build.gradle                  # 项目依赖
```

### 核心页面实现

#### 1. 登录与注册页面
```java
// LoginActivity.java
public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnLogin, btnRegister;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        // 初始化视图
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btn_register);
        
        // 登录按钮点击事件
        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString();
            String password = etPassword.getText().toString();
            login(username, password);
        });
        
        // 注册按钮点击事件
        btnRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }
    
    private void login(String username, String password) {
        // 创建请求参数
        JSONObject params = new JSONObject();
        try {
            params.put("username", username);
            params.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        
        // 创建异步任务请求
        new Thread(() -> {
            try {
                // 发送HTTP请求
                URL url = new URL("http://your-server-url/api/auth/login");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                
                // 写入请求参数
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(params.toString());
                writer.flush();
                
                // 获取响应
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    // 解析响应JSON
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    
                    // 通过Handler回到主线程更新UI
                    new Handler(Looper.getMainLooper()).post(() -> {
                        try {
                            if (jsonResponse.getInt("code") == 200) {
                                JSONObject data = jsonResponse.getJSONObject("data");
                                String token = data.getString("token");
                                
                                // 保存token到SharedPreferences
                                SharedPreferences sp = getSharedPreferences("user_info", MODE_PRIVATE);
                                sp.edit().putString("token", token).apply();
                                
                                // 跳转到主页
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(LoginActivity.this, 
                                    jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(() -> {
                    Toast.makeText(LoginActivity.this, "网络请求失败", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
}
```

#### 2. 主页实现
```java
// MainActivity.java
public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNav;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        bottomNav = findViewById(R.id.bottom_navigation);
        
        // 设置底部导航栏的选择监听
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                selectedFragment = new HomeFragment();
            } else if (itemId == R.id.nav_space) {
                selectedFragment = new SpaceFragment();
            } else if (itemId == R.id.nav_activity) {
                selectedFragment = new ActivityFragment();
            } else if (itemId == R.id.nav_volunteer) {
                selectedFragment = new VolunteerFragment();
            } else if (itemId == R.id.nav_profile) {
                selectedFragment = new ProfileFragment();
            }
            
            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, selectedFragment)
                    .commit();
            }
            
            return true;
        });
        
        // 默认选中首页
        bottomNav.setSelectedItemId(R.id.nav_home);
    }
}
```

#### 3. 公共空间预约Fragment
```java
// SpaceFragment.java
public class SpaceFragment extends Fragment {
    private RecyclerView recyclerView;
    private SpaceAdapter adapter;
    private List<Space> spaceList;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_space, container, false);
        
        // 初始化RecyclerView
        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        spaceList = new ArrayList<>();
        adapter = new SpaceAdapter(spaceList);
        recyclerView.setAdapter(adapter);
        
        // 设置点击监听
        adapter.setOnItemClickListener(position -> {
            Space space = spaceList.get(position);
            Intent intent = new Intent(getActivity(), SpaceDetailActivity.class);
            intent.putExtra("space_id", space.getId());
            startActivity(intent);
        });
        
        // 加载数据
        loadSpaces();
        
        return view;
    }
    
    private void loadSpaces() {
        new Thread(() -> {
            try {
                // 发送HTTP请求获取空间列表
                URL url = new URL("http://your-server-url/api/space/list");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                
                // 获取SharedPreferences中保存的token
                SharedPreferences sp = getActivity().getSharedPreferences("user_info", Context.MODE_PRIVATE);
                String token = sp.getString("token", "");
                
                // 设置请求头
                conn.setRequestProperty("Authorization", token);
                
                // 获取响应
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    // 解析响应JSON
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    
                    // 通过Handler回到主线程更新UI
                    new Handler(Looper.getMainLooper()).post(() -> {
                        try {
                            if (jsonResponse.getInt("code") == 200) {
                                JSONArray data = jsonResponse.getJSONObject("data").getJSONArray("list");
                                
                                // 清空原有数据
                                spaceList.clear();
                                
                                // 添加新数据
                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject item = data.getJSONObject(i);
                                    Space space = new Space();
                                    space.setId(item.getLong("id"));
                                    space.setName(item.getString("name"));
                                    space.setDescription(item.getString("description"));
                                    space.setLocation(item.getString("location"));
                                    space.setCapacity(item.getInt("capacity"));
                                    space.setImageUrl(item.getString("imageUrl"));
                                    spaceList.add(space);
                                }
                                
                                // 通知适配器数据变化
                                adapter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getActivity(), 
                                    jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(() -> {
                    Toast.makeText(getActivity(), "网络请求失败", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
}
```

### 数据模型示例

```java
// Space.java
public class Space {
    private long id;
    private String name;
    private String description;
    private String location;
    private int capacity;
    private String imageUrl;
    private int status;
    
    // 省略getter和setter方法
}

// Activity.java
public class Activity {
    private long id;
    private String title;
    private String description;
    private String imageUrl;
    private Date startTime;
    private Date endTime;
    private String location;
    private int capacity;
    private int registeredCount;
    private int type;
    private int status;
    
    // 省略getter和setter方法
}

// VolunteerService.java
public class VolunteerService {
    private long id;
    private String title;
    private String description;
    private String imageUrl;
    private Date startTime;
    private Date endTime;
    private String location;
    private int capacity;
    private float hours;
    private int status;
    
    // 省略getter和setter方法
}
```

## Java后端实现方案

### 项目结构
```
src/main/java/com/example/springboot/
├── Application.java                  # 应用入口
├── common/                           # 通用类
│   ├── PageResult.java               # 分页结果
│   ├── R.java                        # 统一返回结果
│   └── ResultCode.java               # 结果状态码
├── config/                           # 配置类
│   ├── JwtConfig.java                # JWT配置
│   ├── JwtInterceptor.java           # JWT拦截器
│   └── WebMvcConfig.java             # Web配置
├── controller/                       # 控制器
│   ├── AuthController.java           # 认证控制器
│   ├── SpaceController.java          # 空间控制器
│   ├── ActivityController.java       # 活动控制器
│   ├── VolunteerController.java      # 志愿服务控制器
│   └── UserController.java           # 用户控制器
├── entity/                           # 实体类
│   ├── User.java                     # 用户实体
│   ├── Space.java                    # 空间实体
│   ├── SpaceBooking.java             # 空间预约实体
│   ├── Activity.java                 # 活动实体
│   ├── ActivityRegistration.java     # 活动报名实体
│   ├── ActivityRating.java           # 活动评价实体
│   ├── VolunteerService.java         # 志愿服务实体
│   └── VolunteerRegistration.java    # 志愿服务报名实体
├── mapper/                           # 数据访问层
│   ├── UserMapper.java               # 用户Mapper
│   ├── SpaceMapper.java              # 空间Mapper
│   ├── ActivityMapper.java           # 活动Mapper
│   └── VolunteerMapper.java          # 志愿服务Mapper
└── service/                          # 服务层
    ├── UserService.java              # 用户服务
    ├── SpaceService.java             # 空间服务
    ├── ActivityService.java          # 活动服务
    └── VolunteerService.java         # 志愿服务
```

### 控制器示例

#### 空间控制器
```java
@RestController
@RequestMapping("/space")
@RequiredArgsConstructor
public class SpaceController {
    
    private final SpaceService spaceService;
    
    /**
     * 获取空间列表
     */
    @GetMapping("/list")
    public R<Page<Space>> list(@RequestParam(defaultValue = "1") Integer current,
                              @RequestParam(defaultValue = "10") Integer size,
                              @RequestParam(required = false) Integer spaceType) {
        Page<Space> page = spaceService.listSpaces(current, size, spaceType);
        return R.success(page, "获取成功");
    }
    
    /**
     * 获取空间详情
     */
    @GetMapping("/detail/{id}")
    public R<Space> detail(@PathVariable Long id) {
        Space space = spaceService.getById(id);
        if (space == null) {
            return R.error(ResultCode.NOT_FOUND, "空间不存在");
        }
        return R.success(space, "获取成功");
    }
    
    /**
     * 获取可用时间段
     */
    @GetMapping("/available-time")
    public R<List<Map<String, Object>>> getAvailableTime(@RequestParam Long spaceId,
                                                        @RequestParam String date) {
        List<Map<String, Object>> timeSlots = spaceService.getAvailableTimeSlots(spaceId, date);
        return R.success(timeSlots, "获取成功");
    }
}
```

#### 活动控制器
```java
@RestController
@RequestMapping("/activity")
@RequiredArgsConstructor
public class ActivityController {
    
    private final ActivityService activityService;
    
    /**
     * 获取活动列表
     */
    @GetMapping("/list")
    public R<Page<Activity>> list(@RequestParam(defaultValue = "1") Integer current,
                                 @RequestParam(defaultValue = "10") Integer size,
                                 @RequestParam(required = false) Integer activityType) {
        Page<Activity> page = activityService.listActivities(current, size, activityType);
        return R.success(page, "获取成功");
    }
    
    /**
     * 获取活动详情
     */
    @GetMapping("/detail/{id}")
    public R<Activity> detail(@PathVariable Long id) {
        Activity activity = activityService.getById(id);
        if (activity == null) {
            return R.error(ResultCode.NOT_FOUND, "活动不存在");
        }
        return R.success(activity, "获取成功");
    }
    
    /**
     * 搜索活动
     */
    @GetMapping("/search")
    public R<Page<Activity>> search(@RequestParam(defaultValue = "1") Integer current,
                                   @RequestParam(defaultValue = "10") Integer size,
                                   @RequestParam String keyword) {
        Page<Activity> page = activityService.searchActivities(current, size, keyword);
        return R.success(page, "搜索成功");
    }
}
```

### 服务层示例

```java
@Service
@RequiredArgsConstructor
public class SpaceServiceImpl implements SpaceService {
    
    private final SpaceMapper spaceMapper;
    private final SpaceBookingMapper spaceBookingMapper;
    
    @Override
    public Page<Space> listSpaces(int current, int size, Integer spaceType) {
        Page<Space> page = new Page<>(current, size);
        LambdaQueryWrapper<Space> queryWrapper = new LambdaQueryWrapper<>();
        
        // 如果有类型筛选
        if (spaceType != null) {
            queryWrapper.eq(Space::getSpaceType, spaceType);
        }
        
        // 只查询状态正常的空间
        queryWrapper.eq(Space::getStatus, 1);
        
        // 按ID排序
        queryWrapper.orderByAsc(Space::getId);
        
        return spaceMapper.selectPage(page, queryWrapper);
    }
    
    @Override
    public Space getById(Long id) {
        return spaceMapper.selectById(id);
    }
    
    @Override
    public List<Map<String, Object>> getAvailableTimeSlots(Long spaceId, String dateStr) {
        // 解析日期
        LocalDate date = LocalDate.parse(dateStr);
        
        // 获取当天预约记录
        LambdaQueryWrapper<SpaceBooking> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(SpaceBooking::getSpaceId, spaceId);
        queryWrapper.between(SpaceBooking::getStartTime, 
                            date.atStartOfDay(), 
                            date.plusDays(1).atStartOfDay());
        queryWrapper.eq(SpaceBooking::getStatus, 1); // 已通过的预约
        
        List<SpaceBooking> bookings = spaceBookingMapper.selectList(queryWrapper);
        
        // 生成时间段列表（假设8:00-22:00，每小时一个时间段）
        List<Map<String, Object>> timeSlots = new ArrayList<>();
        for (int hour = 8; hour < 22; hour++) {
            LocalDateTime startTime = date.atTime(hour, 0);
            LocalDateTime endTime = date.atTime(hour + 1, 0);
            
            Map<String, Object> slot = new HashMap<>();
            slot.put("startTime", startTime.format(DateTimeFormatter.ofPattern("HH:mm")));
            slot.put("endTime", endTime.format(DateTimeFormatter.ofPattern("HH:mm")));
            
            // 检查是否已被预约
            boolean isAvailable = true;
            for (SpaceBooking booking : bookings) {
                LocalDateTime bookingStart = booking.getStartTime();
                LocalDateTime bookingEnd = booking.getEndTime();
                
                if (!(bookingEnd.isBefore(startTime) || bookingStart.isAfter(endTime))) {
                    isAvailable = false;
                    break;
                }
            }
            
            slot.put("available", isAvailable);
            timeSlots.add(slot);
        }
        
        return timeSlots;
    }
}
```

### 活动评价控制器

```java
@RestController
@RequestMapping("/activities")
@RequiredArgsConstructor
public class ActivityRatingController {
    
    private final ActivityRatingService activityRatingService;
    
    /**
     * 提交活动评价
     */
    @PostMapping("/{id}/ratings")
    public R<Boolean> rateActivity(@PathVariable Long id, 
                                  @RequestBody ActivityRating rating,
                                  HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        
        // 设置关联信息
        rating.setActivityId(id);
        rating.setUserId(userId);
        
        boolean result = activityRatingService.addRating(rating);
        return R.success(result, "评价成功");
    }
    
    /**
     * 获取活动评价列表
     */
    @GetMapping("/{id}/ratings")
    public R<List<ActivityRating>> getActivityRatings(@PathVariable Long id) {
        List<ActivityRating> ratings = activityRatingService.getRatingsByActivityId(id);
        return R.success(ratings, "获取成功");
    }
}
```

### 活动评价服务实现

```java
@Service
@RequiredArgsConstructor
public class ActivityRatingServiceImpl implements ActivityRatingService {
    
    private final ActivityRatingMapper activityRatingMapper;
    private final ActivityMapper activityMapper;
    
    @Override
    public boolean addRating(ActivityRating rating) {
        // 设置评价时间
        rating.setCreateTime(LocalDateTime.now());
        
        // 保存评价
        int result = activityRatingMapper.insert(rating);
        
        if (result > 0) {
            // 更新活动平均评分
            updateActivityAverageRating(rating.getActivityId());
            return true;
        }
        
        return false;
    }
    
    @Override
    public List<ActivityRating> getRatingsByActivityId(Long activityId) {
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getActivityId, activityId);
        queryWrapper.orderByDesc(ActivityRating::getCreateTime);
        
        return activityRatingMapper.selectList(queryWrapper);
    }
    
    /**
     * 更新活动平均评分
     */
    private void updateActivityAverageRating(Long activityId) {
        // 计算平均评分
        LambdaQueryWrapper<ActivityRating> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRating::getActivityId, activityId);
        List<ActivityRating> ratings = activityRatingMapper.selectList(queryWrapper);
        
        if (!ratings.isEmpty()) {
            double averageRating = ratings.stream()
                .mapToDouble(ActivityRating::getRating)
                .average()
                .orElse(0);
            
            // 更新活动评分
            Activity activity = activityMapper.selectById(activityId);
            if (activity != null) {
                activity.setAverageRating((float) averageRating);
                activityMapper.updateById(activity);
            }
        }
    }
}
```

### 预约提醒实现

```java
@Service
@RequiredArgsConstructor
public class SpaceBookingServiceImpl implements SpaceBookingService {
    
    private final SpaceBookingMapper spaceBookingMapper;
    private final SpaceMapper spaceMapper;
    
    // ... 其他方法 ...
    
    @Override
    public boolean createBooking(SpaceBooking booking) {
        // 设置创建时间和状态
        booking.setCreateTime(LocalDateTime.now());
        booking.setStatus(0); // 待审核
        
        // 保存预约
        int result = spaceBookingMapper.insert(booking);
        
        // 如果预约成功，则设置提醒
        if (result > 0) {
            // 在真实应用中，这里可以使用消息队列或定时任务来实现提醒功能
            // 简化版实现仅记录需要提醒的时间
            booking.setReminderTime(booking.getStartTime().minusHours(1)); // 提前1小时提醒
            spaceBookingMapper.updateById(booking);
            return true;
        }
        
        return false;
    }
    
    /**
     * 处理预约提醒
     * 注意：此方法在实际应用中应由定时任务调用
     */
    @Scheduled(fixedRate = 60000) // 每分钟执行一次
    public void handleBookingReminders() {
        LocalDateTime now = LocalDateTime.now();
        
        // 查找需要提醒的预约
        LambdaQueryWrapper<SpaceBooking> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(SpaceBooking::getStatus, 1); // 已通过的预约
        queryWrapper.le(SpaceBooking::getReminderTime, now); // 提醒时间已到
        queryWrapper.isNull(SpaceBooking::getReminderSent); // 尚未发送提醒
        
        List<SpaceBooking> bookingsToRemind = spaceBookingMapper.selectList(queryWrapper);
        
        for (SpaceBooking booking : bookingsToRemind) {
            // 获取预约的空间信息
            Space space = spaceMapper.selectById(booking.getSpaceId());
            
            // 发送提醒通知（实际应用中可以使用推送服务或短信服务）
            System.out.println("发送预约提醒：用户ID=" + booking.getUserId() 
                + ", 空间=" + space.getName() 
                + ", 时间=" + booking.getStartTime());
            
            // 标记提醒已发送
            booking.setReminderSent(1);
            spaceBookingMapper.updateById(booking);
        }
    }
}
```

## 图像和资源管理

### 图像加载
Android端使用简单的图片加载方式：
```java
// 在适配器中加载图片
public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
    Space space = spaceList.get(position);
    holder.tvName.setText(space.getName());
    holder.tvLocation.setText(space.getLocation());
    
    // 使用异步任务加载图片
    new Thread(() -> {
        try {
            URL url = new URL(space.getImageUrl());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            
            // 在主线程中设置图片
            new Handler(Looper.getMainLooper()).post(() -> {
                holder.ivImage.setImageBitmap(bitmap);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }).start();
}
```

### 资源文件目录
```
res/
├── drawable/       # 图像资源
├── layout/         # 布局文件
│   ├── activity_login.xml
│   ├── activity_main.xml
│   ├── fragment_home.xml
│   ├── fragment_space.xml
│   ├── fragment_activity.xml
│   ├── fragment_volunteer.xml
│   └── fragment_profile.xml
├── menu/           # 菜单文件
│   └── bottom_nav_menu.xml
└── values/         # 值资源
    ├── colors.xml
    ├── strings.xml
    └── styles.xml
```

## 通信安全

### JWT Token处理
Android端保存和使用Token：
```java
// 保存Token
SharedPreferences sp = getSharedPreferences("user_info", MODE_PRIVATE);
sp.edit().putString("token", token).apply();

// 使用Token
SharedPreferences sp = getSharedPreferences("user_info", MODE_PRIVATE);
String token = sp.getString("token", "");
connection.setRequestProperty("Authorization", token);
```

### 服务端Token验证
```java
@Component
public class JwtInterceptor implements HandlerInterceptor {
    
    @Autowired
    private JwtConfig jwtConfig;
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从请求头中获取token
        String token = request.getHeader("Authorization");
        
        // 如果没有token
        if (StringUtils.isEmpty(token)) {
            throw new ServiceException(ResultCode.UNAUTHORIZED, "未登录");
        }
        
        try {
            // 验证token
            Claims claims = jwtConfig.getTokenClaims(token);
            if (claims == null) {
                throw new ServiceException(ResultCode.UNAUTHORIZED, "token无效");
            }
            
            // 判断token是否过期
            Date expiration = claims.getExpiration();
            if (expiration.before(new Date())) {
                throw new ServiceException(ResultCode.UNAUTHORIZED, "token已过期");
            }
            
            // 将用户ID存入request中，方便后续使用
            Long userId = Long.valueOf(claims.get("userId").toString());
            request.setAttribute("userId", userId);
            
            return true;
        } catch (Exception e) {
            throw new ServiceException(ResultCode.UNAUTHORIZED, "token验证失败");
        }
    }
}
```

## 部署指南

### Android APK打包
1. 在Android Studio中选择Build > Generate Signed Bundle / APK
2. 选择APK并创建/选择密钥库文件
3. 填写密钥相关信息
4. 选择release版本并完成打包

### 后端部署
1. 使用Maven打包项目：`mvn clean package`
2. 运行生成的JAR文件：`java -jar your-application.jar`
3. 配置application.properties文件，设置数据库连接等参数

## 后续优化方向

1. 使用Retrofit替代原生HTTP请求，简化网络操作
2. 添加图片缓存机制，提高加载速度
3. 实现消息推送功能，及时通知用户
4. 优化UI界面，提升用户体验
5. 增加数据加密传输，提高安全性

### 活动评价功能实现

```java
// ActivityDetailActivity.java中添加评价功能
private void setupRatingFunction() {
    RatingBar ratingBar = findViewById(R.id.rating_bar);
    EditText etComment = findViewById(R.id.et_comment);
    Button btnSubmitRating = findViewById(R.id.btn_submit_rating);
    
    // 提交评价按钮点击事件
    btnSubmitRating.setOnClickListener(v -> {
        float rating = ratingBar.getRating();
        String comment = etComment.getText().toString();
        
        if (rating == 0) {
            Toast.makeText(this, "请选择评分", Toast.LENGTH_SHORT).show();
            return;
        }
        
        submitRating(rating, comment);
    });
}

private void submitRating(float rating, String comment) {
    // 创建请求参数
    JSONObject params = new JSONObject();
    try {
        params.put("rating", rating);
        params.put("comment", comment);
    } catch (JSONException e) {
        e.printStackTrace();
    }
    
    // 获取活动ID
    long activityId = getIntent().getLongExtra("activity_id", 0);
    
    // 创建异步任务请求
    new Thread(() -> {
        try {
            // 获取token
            SharedPreferences sp = getSharedPreferences("user_info", MODE_PRIVATE);
            String token = sp.getString("token", "");
            
            // 发送HTTP请求
            URL url = new URL("http://your-server-url/api/activities/" + activityId + "/ratings");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", token);
            conn.setDoOutput(true);
            
            // 写入请求参数
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            writer.write(params.toString());
            writer.flush();
            
            // 获取响应
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                
                // 解析响应JSON
                JSONObject jsonResponse = new JSONObject(response.toString());
                
                // 通过Handler回到主线程更新UI
                new Handler(Looper.getMainLooper()).post(() -> {
                    try {
                        if (jsonResponse.getInt("code") == 200) {
                            Toast.makeText(ActivityDetailActivity.this, 
                                "评价提交成功", Toast.LENGTH_SHORT).show();
                            // 清空输入
                            ((EditText)findViewById(R.id.et_comment)).setText("");
                            ((RatingBar)findViewById(R.id.rating_bar)).setRating(0);
                        } else {
                            Toast.makeText(ActivityDetailActivity.this, 
                                jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            new Handler(Looper.getMainLooper()).post(() -> {
                Toast.makeText(ActivityDetailActivity.this, "网络请求失败", Toast.LENGTH_SHORT).show();
            });
        }
    }).start();
}
```

### 切换账户功能实现（纯客户端功能）

```java
// ProfileFragment.java中添加切换账户功能
private void setupSwitchAccountButton() {
    Button btnSwitchAccount = view.findViewById(R.id.btn_switch_account);
    
    btnSwitchAccount.setOnClickListener(v -> {
        // 弹出对话框确认是否切换账户
        new AlertDialog.Builder(getContext())
            .setTitle("切换账户")
            .setMessage("确定要切换到其他账户吗？")
            .setPositiveButton("确定", (dialog, which) -> {
                // 清除当前登录信息
                SharedPreferences sp = getContext().getSharedPreferences("user_info", Context.MODE_PRIVATE);
                sp.edit().clear().apply();
                
                // 跳转到登录页面
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            })
            .setNegativeButton("取消", null)
            .show();
    });
}
```

## 通知系统实现

### Firebase Cloud Messaging配置

#### 1. 项目配置

确保项目根目录包含`google-services.json`文件，该文件包含Firebase项目的配置信息。

#### 2. 添加依赖

在应用级`build.gradle`文件中添加Firebase依赖：

```gradle
dependencies {
    // Firebase Cloud Messaging
    implementation 'com.google.firebase:firebase-messaging:23.1.2'
    
    // 其他依赖...
}
```

在项目级`build.gradle`文件中添加Google服务插件：

```gradle
buildscript {
    dependencies {
        classpath 'com.google.gms:google-services:4.3.15'
    }
}
```

并在应用级`build.gradle`文件底部应用插件：

```gradle
apply plugin: 'com.google.gms.google-services'
```

### Firebase消息接收服务

创建一个继承自`FirebaseMessagingService`的服务类来处理接收到的消息：

```java
// MyFirebaseMessagingService.java
public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "FCM_Service";

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        // 将新token发送到服务器
        sendRegistrationToServer(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // 检查消息是否包含数据
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            handleNow(remoteMessage.getData());
        }

        // 检查消息是否包含通知
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
            sendNotification(remoteMessage.getNotification().getTitle(), 
                            remoteMessage.getNotification().getBody());
        }
    }

    private void handleNow(Map<String, String> data) {
        String type = data.get("type");
        
        if ("booking".equals(type)) {
            // 处理预约相关通知
            String bookingId = data.get("bookingId");
            String status = data.get("status");
            
            // 创建通知
            String title = "预约状态更新";
            String message = "您的预约状态已更新为: " + status;
            sendNotification(title, message);
            
            // 如果是即将到来的预约，设置本地提醒
            if ("upcoming".equals(status)) {
                String timeStr = data.get("time");
                long reminderTime = Long.parseLong(timeStr);
                setAlarmForBooking(bookingId, reminderTime);
            }
        } else if ("activity".equals(type)) {
            // 处理活动相关通知
            sendNotification("活动提醒", data.get("message"));
        } else if ("volunteer".equals(type)) {
            // 处理志愿服务相关通知
            sendNotification("志愿服务提醒", data.get("message"));
        }
    }

    private void sendRegistrationToServer(String token) {
        // 获取用户ID
        SharedPreferences sp = getSharedPreferences("user_info", MODE_PRIVATE);
        String userId = sp.getString("user_id", "");
        
        if (TextUtils.isEmpty(userId)) {
            return;
        }
        
        // 创建异步任务发送token到服务器
        new Thread(() -> {
            try {
                // 获取认证token
                String authToken = sp.getString("token", "");
                
                URL url = new URL("http://your-server-url/api/users/fcm-token");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", authToken);
                conn.setDoOutput(true);
                
                // 构建请求体
                JSONObject jsonParam = new JSONObject();
                jsonParam.put("fcmToken", token);
                
                // 发送请求
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(jsonParam.toString());
                writer.flush();
                
                // 检查响应
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    Log.d(TAG, "FCM token successfully sent to server");
                } else {
                    Log.e(TAG, "Failed to send FCM token to server, response code: " + responseCode);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error sending FCM token to server", e);
            }
        }).start();
    }

    private void sendNotification(String title, String messageBody) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE);

        String channelId = "default_channel";
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.ic_notification)
                        .setContentTitle(title)
                        .setContentText(messageBody)
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // 适配Android 8.0及以上版本的通知渠道
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId,
                    "校园预约通知",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(0, notificationBuilder.build());
    }

    private void setAlarmForBooking(String bookingId, long reminderTime) {
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("bookingId", bookingId);
        intent.putExtra("notificationType", "booking_reminder");
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, 
                bookingId.hashCode(), 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        
        // 设置精确闹钟，在提醒时间触发
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );
        } else {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );
        }
        
        Log.d(TAG, "Alarm set for booking: " + bookingId + " at time: " + reminderTime);
    }
}
```

### 本地提醒实现（AlarmManager与BroadcastReceiver）

创建一个`BroadcastReceiver`来处理本地提醒：

```java
// AlarmReceiver.java
public class AlarmReceiver extends BroadcastReceiver {
    private static final String TAG = "AlarmReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String bookingId = intent.getStringExtra("bookingId");
        String notificationType = intent.getStringExtra("notificationType");
        
        Log.d(TAG, "Received alarm for booking: " + bookingId + ", type: " + notificationType);
        
        if ("booking_reminder".equals(notificationType)) {
            // 获取预约详情
            retrieveBookingDetails(context, bookingId);
        }
    }
    
    private void retrieveBookingDetails(Context context, String bookingId) {
        // 从SharedPreferences获取token
        SharedPreferences sp = context.getSharedPreferences("user_info", Context.MODE_PRIVATE);
        String token = sp.getString("token", "");
        
        if (TextUtils.isEmpty(token)) {
            return;
        }
        
        // 创建异步任务获取预约详情
        new Thread(() -> {
            try {
                URL url = new URL("http://your-server-url/api/bookings/" + bookingId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", token);
                
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    
                    // 解析预约详情
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    if (jsonResponse.getInt("code") == 200) {
                        JSONObject data = jsonResponse.getJSONObject("data");
                        String spaceName = data.getString("spaceName");
                        String startTime = data.getString("startTime");
                        
                        // 创建通知
                        showBookingReminder(context, bookingId, spaceName, startTime);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving booking details", e);
            }
        }).start();
    }
    
    private void showBookingReminder(Context context, String bookingId, String spaceName, String startTime) {
        Intent intent = new Intent(context, SpaceDetailActivity.class);
        intent.putExtra("booking_id", bookingId);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 
                bookingId.hashCode(), 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        NotificationManager notificationManager = 
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        
        String channelId = "reminder_channel";
        
        // 适配Android 8.0及以上版本的通知渠道
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "预约提醒",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.enableVibration(true);
            channel.enableLights(true);
            notificationManager.createNotificationChannel(channel);
        }
        
        // 构建通知
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("预约即将开始")
                .setContentText("您在" + spaceName + "的预约将于" + startTime + "开始")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .setLights(Color.BLUE, 3000, 3000);
        
        // 显示通知
        notificationManager.notify(bookingId.hashCode(), builder.build());
    }
}
```

### 在AndroidManifest.xml中注册服务和接收器

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.studentcommunity">

    <!-- 权限声明 -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    
    <application
        ...>
        
        <!-- Firebase消息服务 -->
        <service
            android:name=".MyFirebaseMessagingService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>
        
        <!-- 本地闹钟接收器 -->
        <receiver
            android:name=".AlarmReceiver"
            android:exported="false" />
            
        <!-- 确保应用重启后闹钟依然有效 -->
        <receiver
            android:name=".BootReceiver"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
        
        ...
    </application>
</manifest>
```

### 启动时重新设置闹钟

为了确保设备重启后闹钟仍然有效，创建一个启动接收器：

```java
// BootReceiver.java
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            // 从数据库或SharedPreferences加载未完成的预约
            loadPendingBookings(context);
        }
    }
    
    private void loadPendingBookings(Context context) {
        // 创建异步任务加载未完成的预约
        new Thread(() -> {
            SharedPreferences sp = context.getSharedPreferences("user_info", Context.MODE_PRIVATE);
            String token = sp.getString("token", "");
            
            if (TextUtils.isEmpty(token)) {
                return;
            }
            
            try {
                URL url = new URL("http://your-server-url/api/bookings/pending");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", token);
                
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    
                    // 解析预约列表
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    if (jsonResponse.getInt("code") == 200) {
                        JSONArray bookings = jsonResponse.getJSONObject("data").getJSONArray("list");
                        
                        // 重新设置每个预约的闹钟
                        for (int i = 0; i < bookings.length(); i++) {
                            JSONObject booking = bookings.getJSONObject(i);
                            String bookingId = booking.getString("id");
                            long startTime = booking.getLong("startTimestamp");
                            
                            // 提前1小时提醒
                            long reminderTime = startTime - 3600000;
                            
                            // 如果提醒时间已经过去，跳过
                            if (reminderTime <= System.currentTimeMillis()) {
                                continue;
                            }
                            
                            // 重新设置闹钟
                            setAlarmForBooking(context, bookingId, reminderTime);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("BootReceiver", "Error loading pending bookings", e);
            }
        }).start();
    }
    
    private void setAlarmForBooking(Context context, String bookingId, long reminderTime) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("bookingId", bookingId);
        intent.putExtra("notificationType", "booking_reminder");
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, 
                bookingId.hashCode(), 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        
        // 设置精确闹钟
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );
        } else {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );
        }
    }
}
```

### 后端实现Firebase消息发送

在后端服务中添加Firebase消息发送功能：

```java
@Service
@RequiredArgsConstructor
public class NotificationService {
    
    private static final String FIREBASE_API_URL = "https://fcm.googleapis.com/v1/projects/campus-reservation-platform/messages:send";
    private static final String SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
    
    private final UserMapper userMapper;
    
    /**
     * 发送预约提醒通知
     */
    public void sendBookingReminder(Long userId, Long bookingId, String spaceName, Date startTime) {
        // 获取用户FCM令牌
        String fcmToken = userMapper.selectFcmTokenByUserId(userId);
        if (StringUtils.isEmpty(fcmToken)) {
            return;
        }
        
        try {
            // 构建消息
            JSONObject message = new JSONObject();
            message.put("token", fcmToken);
            
            // 消息数据
            JSONObject data = new JSONObject();
            data.put("type", "booking");
            data.put("bookingId", bookingId.toString());
            data.put("status", "upcoming");
            data.put("time", startTime.getTime());
            message.put("data", data);
            
            // 消息通知
            JSONObject notification = new JSONObject();
            notification.put("title", "预约提醒");
            notification.put("body", "您在" + spaceName + "的预约即将开始");
            message.put("notification", notification);
            
            // 构建请求体
            JSONObject requestBody = new JSONObject();
            requestBody.put("message", message);
            
            // 发送消息
            sendFirebaseMessage(requestBody.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 发送活动提醒通知
     */
    public void sendActivityReminder(Long userId, Long activityId, String activityTitle) {
        // 获取用户FCM令牌
        String fcmToken = userMapper.selectFcmTokenByUserId(userId);
        if (StringUtils.isEmpty(fcmToken)) {
            return;
        }
        
        try {
            // 构建消息
            JSONObject message = new JSONObject();
            message.put("token", fcmToken);
            
            // 消息数据
            JSONObject data = new JSONObject();
            data.put("type", "activity");
            data.put("activityId", activityId.toString());
            data.put("message", "您报名的活动\"" + activityTitle + "\"即将开始");
            message.put("data", data);
            
            // 消息通知
            JSONObject notification = new JSONObject();
            notification.put("title", "活动提醒");
            notification.put("body", "您报名的活动\"" + activityTitle + "\"即将开始");
            message.put("notification", notification);
            
            // 构建请求体
            JSONObject requestBody = new JSONObject();
            requestBody.put("message", message);
            
            // 发送消息
            sendFirebaseMessage(requestBody.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 发送志愿服务提醒通知
     */
    public void sendVolunteerReminder(Long userId, Long serviceId, String serviceTitle) {
        // 获取用户FCM令牌
        String fcmToken = userMapper.selectFcmTokenByUserId(userId);
        if (StringUtils.isEmpty(fcmToken)) {
            return;
        }
        
        try {
            // 构建消息
            JSONObject message = new JSONObject();
            message.put("token", fcmToken);
            
            // 消息数据
            JSONObject data = new JSONObject();
            data.put("type", "volunteer");
            data.put("serviceId", serviceId.toString());
            data.put("message", "您报名的志愿服务\"" + serviceTitle + "\"即将开始");
            message.put("data", data);
            
            // 消息通知
            JSONObject notification = new JSONObject();
            notification.put("title", "志愿服务提醒");
            notification.put("body", "您报名的志愿服务\"" + serviceTitle + "\"即将开始");
            message.put("notification", notification);
            
            // 构建请求体
            JSONObject requestBody = new JSONObject();
            requestBody.put("message", message);
            
            // 发送消息
            sendFirebaseMessage(requestBody.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 发送Firebase消息
     */
    private void sendFirebaseMessage(String requestBody) throws Exception {
        // 获取访问令牌
        String accessToken = getAccessToken();
        
        // 创建连接
        URL url = new URL(FIREBASE_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Content-Type", "application/json; UTF-8");
        conn.setDoOutput(true);
        
        // 发送请求
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        
        // 读取响应
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("FCM HTTP error: " + responseCode);
        }
    }
    
    /**
     * 获取Firebase访问令牌
     */
    private String getAccessToken() throws Exception {
        // 实际应用中，应该使用Google提供的库获取访问令牌
        // 以下是简化的示例，实际项目中请使用正确的认证方式
        
        // 从服务账号文件获取凭据
        GoogleCredentials googleCredentials = GoogleCredentials
                .fromStream(new FileInputStream("path/to/service-account.json"))
                .createScoped(Collections.singleton(SCOPE));
        
        // 刷新凭据
        googleCredentials.refreshIfExpired();
        
        // 获取访问令牌
        return googleCredentials.getAccessToken().getTokenValue();
    }
}
```

### 后端控制器更新

在用户控制器中添加更新FCM令牌的接口：

```java
@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {
    
    private final UserService userService;
    
    // ... 其他方法 ...
    
    /**
     * 更新FCM令牌
     */
    @PostMapping("/fcm-token")
    public R<Boolean> updateFcmToken(@RequestBody Map<String, String> params, HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        String fcmToken = params.get("fcmToken");
        
        boolean result = userService.updateFcmToken(userId, fcmToken);
        return R.success(result);
    }
}
```

在用户服务中实现更新FCM令牌的方法：

```java
@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    
    // ... 其他方法 ...
    
    @Override
    public boolean updateFcmToken(Long userId, String fcmToken) {
        return this.baseMapper.updateFcmToken(userId, fcmToken) > 0;
    }
}
```

在用户Mapper中添加更新FCM令牌的方法：

```java
@Mapper
public interface UserMapper extends BaseMapper<User> {
    
    // ... 其他方法 ...
    
    @Update("UPDATE user SET fcm_token = #{fcmToken} WHERE id = #{userId}")
    int updateFcmToken(@Param("userId") Long userId, @Param("fcmToken") String fcmToken);
    
    @Select("SELECT fcm_token FROM user WHERE id = #{userId}")
    String selectFcmTokenByUserId(@Param("userId") Long userId);
}
```

## 功能总结

基于上述实现，通知系统具备以下功能：

1. **远程推送通知**：使用Firebase Cloud Messaging实现服务器到设备的消息推送
2. **本地提醒**：使用AlarmManager和BroadcastReceiver实现本地定时提醒
3. **多层次通知体系**：
   - 即时通知：预约确认、活动报名成功等
   - 提前提醒：预约即将开始、活动即将开始等
   - 状态变更通知：预约状态变更、活动状态变更等
4. **跨平台支持**：Firebase支持Android和iOS平台
5. **通知持久化**：设备重启后自动恢复未触发的提醒

// ... 保留后续内容不变 ... 